﻿
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
    Private db As New BusinessLogicDB()
    Public cn1 As String = ConfigurationManager.ConnectionStrings("conStringFarmacia").ConnectionString
    Public cn2 As String = ConfigurationManager.ConnectionStrings("conString").ConnectionString
    Public errores As String = ""
    Private revisar As New Rsesion()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim sessionTimeout As Integer = Session.Timeout
        Dim valortimeout As Integer = Convert.ToInt16(ConfigurationManager.AppSettings("timeout"))
        sessionTimeout = sessionTimeout * valortimeout
        Dim value As String = sessionTimeout.ToString() & "; url=logout.aspx"
        Response.AppendHeader("Refresh", value)
        If Not Page.IsPostBack Then
            Response.Buffer = True
            Response.ExpiresAbsolute = DateTime.Now.AddDays(-1.0)
            Response.Expires = -1500
            Response.CacheControl = "no-cache"
            'Dim rol As String = Convert.ToString(Session("pusuario"))
            lbl_nombre.Text = Session("usuario").ToString()
            'Dim acceso As String = Session("accesos").ToString()
            'Dim a As String() = acceso.Split(",")
            'Dim u As String = ConfigurationManager.AppSettings("root").ToString()
            'Dim pagina As String = If(u = "1", Request.Url.Segments(1).ToLowerInvariant(), Request.Url.Segments(2).ToLowerInvariant())
            Session("ip") = Request.UserHostAddress
            If Not revisar.RevisaSesion(Session("conexion").ToString(), Session("usuario").ToString()) Then
                Response.Redirect("~/inicio.aspx", False)
            End If
        End If
    End Sub

    'Protected Sub lkb_conexion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lkb_conexion.Click
    '    Response.Redirect("~/logout.aspx", False)
    'End Sub

    Protected Sub IB_conexion_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles IB_conexion.Click
        Response.Redirect("~/logout.aspx", False)
    End Sub
End Class

