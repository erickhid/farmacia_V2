﻿Imports System.Data

Partial Class consultaReg
    Inherits System.Web.UI.Page
    Private revisar As New Rsesion()
    Private db As New BusinessLogicDB()
    Public cn1 As String = ConfigurationManager.ConnectionStrings("conStringFarmacia").ConnectionString
    Public cn2 As String = ConfigurationManager.ConnectionStrings("conString").ConnectionString
    Public usuario As String = ""
    Public errores As String = ""
    Public strnhc As String
    Public existenhc As Boolean
    Public ufecha As Boolean
    Public idufecha As String
    Public idarv As String
    Public idprof As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Response.Buffer = True
            Response.ExpiresAbsolute = DateTime.Now.AddDays(-1.0)
            Response.Expires = -1500
            Response.CacheControl = "no-cache"
            If Not revisar.RevisaSesion(Session("conexion").ToString(), Session("usuario").ToString()) Then
                Response.Redirect("~/inicio.aspx", False)
            Else
                usuario = Session("usuario").ToString()
                ufecha = False
                llenadatos(Request.QueryString("nhc").ToUpper())
                Llena_regPac(Request.QueryString("nhc").ToUpper())
            End If
        End If
    End Sub

    Private Sub Llena_regPac(ByVal nhc As String)
        Try
            db.Cn1 = cn1
            usuario = Session("usuario").ToString()
            Dim tbpacA As DataTable = db.RegistrosPacienteARV(nhc, usuario)
            Session("dspacA") = tbpacA
            GV_regPacA.DataSource = tbpacA
            GV_regPacA.DataBind()
            GV_regPacA.SelectedIndex = 0
            Dim tbpacP As DataTable = db.RegistrosPacienteProf(nhc, usuario)
            Session("dspacP") = tbpacP
            GV_regPacP.DataSource = tbpacP
            GV_regPacP.DataBind()
            GV_regPacP.SelectedIndex = 0
        Catch ex As Exception
            'lbl_error.Text = "Hubo un error al mostrar las Propiedades."
            errores = (usuario & "|Pacientes.Llena_regPac()|" & ex.ToString() & "|") + ex.Message
            db.GrabarErrores(errores)
        End Try
    End Sub

    Sub llenaregistro(ByVal id As String)
        db.Cn1 = cn1
        Dim y As String = db.ObtieneRegARV(id, usuario)
        Dim rpU As String() = y.Split("|")
        If rpU(0).ToString() = "True" Then
            idarv = rpU(1).ToString()
            lbl_fe.Text = rpU(2).Substring(0, 10).ToString()
            DDL_cod1.SelectedValue = rpU(3).ToString()
            txt_cant1.Text = rpU(4).ToString()
            txt_dx1.Text = rpU(5).ToString()
            DDL_fx1.SelectedValue = rpU(6).ToString()
            txt_uecant1.Text = rpU(7).ToString()
            DDL_earv1.SelectedValue = rpU(8).ToString()
            txt_devcant1.Text = rpU(9).ToString()
            DDL_cod2.SelectedValue = rpU(10).ToString()
            txt_cant2.Text = rpU(11).ToString()
            txt_dx2.Text = rpU(12).ToString()
            DDL_fx2.SelectedValue = rpU(13).ToString()
            txt_uecant2.Text = rpU(14).ToString()
            DDL_earv2.SelectedValue = rpU(15).ToString()
            txt_devcant2.Text = rpU(16).ToString()
            DDL_cod3.SelectedValue = rpU(17).ToString()
            txt_cant3.Text = rpU(18).ToString()
            txt_dx3.Text = rpU(19).ToString()
            DDL_fx3.SelectedValue = rpU(20).ToString()
            txt_uecant3.Text = rpU(21).ToString()
            DDL_earv3.SelectedValue = rpU(22).ToString()
            txt_devcant3.Text = rpU(23).ToString()
            DDL_cod4.SelectedValue = rpU(24).ToString()
            txt_cant4.Text = rpU(25).ToString()
            txt_dx4.Text = rpU(26).ToString()
            DDL_fx4.SelectedValue = rpU(27).ToString()
            txt_uecant4.Text = rpU(28).ToString()
            DDL_earv4.SelectedValue = rpU(29).ToString()
            txt_devcant4.Text = rpU(30).ToString()
            DDL_cod5.SelectedValue = rpU(31).ToString()
            txt_cant5.Text = rpU(32).ToString()
            txt_dx5.Text = rpU(33).ToString()
            DDL_fx5.SelectedValue = rpU(34).ToString()
            txt_uecant5.Text = rpU(35).ToString()
            DDL_earv5.SelectedValue = rpU(36).ToString()
            txt_devcant5.Text = rpU(37).ToString()
            DDL_cod6.SelectedValue = rpU(38).ToString()
            txt_cant6.Text = rpU(39).ToString()
            txt_dx6.Text = rpU(40).ToString()
            DDL_fx6.SelectedValue = rpU(41).ToString()
            txt_uecant6.Text = rpU(42).ToString()
            DDL_earv6.SelectedValue = rpU(43).ToString()
            txt_devcant6.Text = rpU(44).ToString()
            DDL_cod7.SelectedValue = rpU(45).ToString()
            txt_cant7.Text = rpU(46).ToString()
            txt_dx7.Text = rpU(47).ToString()
            DDL_fx7.SelectedValue = rpU(48).ToString()
            txt_uecant7.Text = rpU(49).ToString()
            DDL_earv7.SelectedValue = rpU(50).ToString()
            txt_devcant7.Text = rpU(51).ToString()
            DDL_cod8.SelectedValue = rpU(52).ToString()
            txt_cant8.Text = rpU(53).ToString()
            txt_dx8.Text = rpU(54).ToString()
            DDL_fx8.SelectedValue = rpU(55).ToString()
            txt_uecant8.Text = rpU(56).ToString()
            DDL_earv8.SelectedValue = rpU(57).ToString()
            txt_devcant8.Text = rpU(58).ToString()
            txt_fr_dd.Text = rpU(59).Substring(0, 2).ToString()
            txt_fr_mm.Text = rpU(59).Substring(3, 2).ToString()
            txt_fr_yy.Text = rpU(59).Substring(6, 4).ToString()
            txt_tarvdias.Text = rpU(60).ToString()
            CB_citaMx.Checked = rpU(61).ToString()
            CB_citaFx.Checked = rpU(62).ToString()
            DDL_embarazo.SelectedValue = rpU(63).ToString()
            txt_retornodias.Text = rpU(64).ToString()
            txt_adherencia.Text = rpU(65).ToString()
            txt_cd4.Text = rpU(66).ToString()
            txt_cv.Text = rpU(67).ToString()
            txt_observaciones.Text = rpU(68).ToString()
        Else
            idarv = String.Empty
            lbl_fe.Text = String.Empty
            DDL_cod1.SelectedValue = String.Empty
            txt_cant1.Text = String.Empty
            txt_dx1.Text = String.Empty
            DDL_fx1.SelectedValue = String.Empty
            txt_uecant1.Text = String.Empty
            DDL_earv1.SelectedValue = String.Empty
            txt_devcant1.Text = String.Empty
            DDL_cod2.SelectedValue = String.Empty
            txt_cant2.Text = String.Empty
            txt_dx2.Text = String.Empty
            DDL_fx2.SelectedValue = String.Empty
            txt_uecant2.Text = String.Empty
            DDL_earv2.SelectedValue = String.Empty
            txt_devcant2.Text = String.Empty
            DDL_cod3.SelectedValue = String.Empty
            txt_cant3.Text = String.Empty
            txt_dx3.Text = String.Empty
            DDL_fx3.SelectedValue = String.Empty
            txt_uecant3.Text = String.Empty
            DDL_earv3.SelectedValue = String.Empty
            txt_devcant3.Text = String.Empty
            DDL_cod4.SelectedValue = String.Empty
            txt_cant4.Text = String.Empty
            txt_dx4.Text = String.Empty
            DDL_fx4.SelectedValue = String.Empty
            txt_uecant4.Text = String.Empty
            DDL_earv4.SelectedValue = String.Empty
            txt_devcant4.Text = String.Empty
            DDL_cod5.SelectedValue = String.Empty
            txt_cant5.Text = String.Empty
            txt_dx5.Text = String.Empty
            DDL_fx5.SelectedValue = String.Empty
            txt_uecant5.Text = String.Empty
            DDL_earv5.SelectedValue = String.Empty
            txt_devcant5.Text = String.Empty
            DDL_cod6.SelectedValue = String.Empty
            txt_cant6.Text = String.Empty
            txt_dx6.Text = String.Empty
            DDL_fx6.SelectedValue = String.Empty
            txt_uecant6.Text = String.Empty
            DDL_earv6.SelectedValue = String.Empty
            txt_devcant6.Text = String.Empty
            DDL_cod7.SelectedValue = String.Empty
            txt_cant7.Text = String.Empty
            txt_dx7.Text = String.Empty
            DDL_fx7.SelectedValue = String.Empty
            txt_uecant7.Text = String.Empty
            DDL_earv7.SelectedValue = String.Empty
            txt_devcant7.Text = String.Empty
            DDL_cod8.SelectedValue = String.Empty
            txt_cant8.Text = String.Empty
            txt_dx8.Text = String.Empty
            DDL_fx8.SelectedValue = String.Empty
            txt_uecant8.Text = String.Empty
            DDL_earv8.SelectedValue = String.Empty
            txt_devcant8.Text = String.Empty
            txt_fr_dd.Text = String.Empty
            txt_fr_mm.Text = String.Empty
            txt_fr_yy.Text = String.Empty
            txt_tarvdias.Text = String.Empty
            CB_citaMx.Checked = String.Empty
            CB_citaFx.Checked = String.Empty
            DDL_embarazo.SelectedValue = String.Empty
            txt_retornodias.Text = String.Empty
            txt_adherencia.Text = String.Empty
            txt_cd4.Text = String.Empty
            txt_cv.Text = String.Empty
            txt_observaciones.Text = String.Empty
        End If
    End Sub

    Sub llenaregistroP(ByVal id As String)
        db.Cn1 = cn1
        Dim y As String = db.ObtieneRegProf(id, usuario)
        Dim rpU As String() = y.Split("|")
        If rpU(0).ToString() = "True" Then
            idprof = rpU(1).ToString()
            lbl_feP.Text = rpU(2).Substring(0, 10).ToString()
            DDL_cod1P.SelectedValue = rpU(3).ToString()
            txt_cant1P.Text = rpU(4).ToString()
            txt_dx1P.Text = rpU(5).ToString()
            DDL_fx1P.SelectedValue = rpU(6).ToString()
            DDL_earv1P.SelectedValue = rpU(7).ToString()
            txt_devcant1P.Text = rpU(8).ToString()
            DDL_cod2P.SelectedValue = rpU(9).ToString()
            txt_cant2P.Text = rpU(10).ToString()
            txt_dx2P.Text = rpU(11).ToString()
            DDL_fx2P.SelectedValue = rpU(12).ToString()
            DDL_earv2P.SelectedValue = rpU(13).ToString()
            txt_devcant2P.Text = rpU(14).ToString()
            DDL_cod3P.SelectedValue = rpU(15).ToString()
            txt_cant3P.Text = rpU(16).ToString()
            txt_dx3P.Text = rpU(17).ToString()
            DDL_fx3P.SelectedValue = rpU(18).ToString()
            DDL_earv3P.SelectedValue = rpU(19).ToString()
            txt_devcant3P.Text = rpU(20).ToString()
            DDL_cod4P.SelectedValue = rpU(21).ToString()
            txt_cant4P.Text = rpU(22).ToString()
            txt_dx4P.Text = rpU(23).ToString()
            DDL_fx4P.SelectedValue = rpU(24).ToString()
            DDL_earv4P.SelectedValue = rpU(25).ToString()
            txt_devcant4P.Text = rpU(26).ToString()
            txt_fr_ddP.Text = rpU(27).Substring(0, 2).ToString()
            txt_fr_mmP.Text = rpU(27).Substring(3, 2).ToString()
            txt_fr_yyP.Text = rpU(27).Substring(6, 4).ToString()
            txt_tarvdiasP.Text = rpU(28).ToString()
            CB_citaMxP.Checked = rpU(29).ToString()
            CB_citaFxP.Checked = rpU(30).ToString()
            DDL_embarazoP.SelectedValue = rpU(31).ToString()
            txt_retornodiasP.Text = rpU(32).ToString()
            txt_cd4P.Text = rpU(33).ToString()
            txt_cvP.Text = rpU(34).ToString()
            txt_observacionesP.Text = rpU(35).ToString()
        Else
            idprof = String.Empty
            lbl_feP.Text = String.Empty
            DDL_cod1P.SelectedValue = String.Empty
            txt_cant1P.Text = String.Empty
            txt_dx1P.Text = String.Empty
            DDL_fx1P.SelectedValue = String.Empty
            DDL_earv1P.SelectedValue = String.Empty
            txt_devcant1P.Text = String.Empty
            DDL_cod2P.SelectedValue = String.Empty
            txt_cant2P.Text = String.Empty
            txt_dx2P.Text = String.Empty
            DDL_fx2P.SelectedValue = String.Empty
            DDL_earv2P.SelectedValue = String.Empty
            txt_devcant2P.Text = String.Empty
            DDL_cod3P.SelectedValue = String.Empty
            txt_cant3P.Text = String.Empty
            txt_dx3P.Text = String.Empty
            DDL_fx3P.SelectedValue = String.Empty
            DDL_earv3P.SelectedValue = String.Empty
            txt_devcant3P.Text = String.Empty
            DDL_cod4P.SelectedValue = String.Empty
            txt_cant4P.Text = String.Empty
            txt_dx4P.Text = String.Empty
            DDL_fx4P.SelectedValue = String.Empty
            DDL_earv4P.SelectedValue = String.Empty
            txt_devcant4P.Text = String.Empty
            txt_fr_ddP.Text = String.Empty
            txt_fr_mmP.Text = String.Empty
            txt_fr_yyP.Text = String.Empty
            txt_tarvdiasP.Text = String.Empty
            CB_citaMxP.Checked = String.Empty
            CB_citaFxP.Checked = String.Empty
            DDL_embarazoP.SelectedValue = String.Empty
            txt_retornodiasP.Text = String.Empty
            txt_cd4P.Text = String.Empty
            txt_cvP.Text = String.Empty
            txt_observacionesP.Text = String.Empty
        End If
    End Sub

    Sub setcampos(ByVal valor As Integer)
        txt_cant1.Text = ""
        txt_dx1.Text = ""
        txt_uecant1.Text = ""
        txt_cant2.Text = ""
        txt_dx2.Text = ""
        txt_uecant2.Text = ""
        txt_cant3.Text = ""
        txt_dx3.Text = ""
        txt_uecant3.Text = ""
        txt_cant4.Text = ""
        txt_dx4.Text = ""
        txt_uecant4.Text = ""
        txt_cant5.Text = ""
        txt_dx5.Text = ""
        txt_uecant5.Text = ""
        txt_cant6.Text = ""
        txt_dx6.Text = ""
        txt_uecant6.Text = ""
        txt_cant7.Text = ""
        txt_dx7.Text = ""
        txt_uecant7.Text = ""
        txt_cant8.Text = ""
        txt_dx8.Text = ""
        txt_uecant8.Text = ""
        Select Case valor
            Case 1
                txt_cant1.Enabled = False
                txt_dx1.Enabled = False
                DDL_fx1.Enabled = False
                txt_uecant1.Enabled = False
                DDL_earv1.Enabled = False
                txt_devcant1.Enabled = False
            Case 2
                txt_cant2.Enabled = False
                txt_dx2.Enabled = False
                DDL_fx2.Enabled = False
                txt_uecant2.Enabled = False
                DDL_earv2.Enabled = False
                txt_devcant2.Enabled = False
            Case 3
                txt_cant3.Enabled = False
                txt_dx3.Enabled = False
                DDL_fx3.Enabled = False
                txt_uecant3.Enabled = False
                DDL_earv3.Enabled = False
                txt_devcant3.Enabled = False
            Case 4
                txt_cant4.Enabled = False
                txt_dx4.Enabled = False
                DDL_fx4.Enabled = False
                txt_uecant4.Enabled = False
                DDL_earv4.Enabled = False
                txt_devcant4.Enabled = False
            Case 5
                txt_cant5.Enabled = False
                txt_dx5.Enabled = False
                DDL_fx5.Enabled = False
                txt_uecant5.Enabled = False
                DDL_earv5.Enabled = False
                txt_devcant5.Enabled = False
            Case 6
                txt_cant6.Enabled = False
                txt_dx6.Enabled = False
                DDL_fx6.Enabled = False
                txt_uecant6.Enabled = False
                DDL_earv6.Enabled = False
                txt_devcant6.Enabled = False
            Case 7
                txt_cant7.Enabled = False
                txt_dx7.Enabled = False
                DDL_fx7.Enabled = False
                txt_uecant7.Enabled = False
                DDL_earv7.Enabled = False
                txt_devcant7.Enabled = False
            Case 8
                txt_cant8.Enabled = False
                txt_dx8.Enabled = False
                DDL_fx8.Enabled = False
                txt_uecant8.Enabled = False
                DDL_earv8.Enabled = False
                txt_devcant8.Enabled = False
            Case 0
                txt_cant1.Enabled = False
                txt_dx1.Enabled = False
                DDL_fx1.Enabled = False
                txt_uecant1.Enabled = False
                DDL_earv1.Enabled = False
                txt_cant2.Enabled = False
                txt_dx2.Enabled = False
                DDL_fx2.Enabled = False
                txt_uecant2.Enabled = False
                DDL_earv2.Enabled = False
                txt_cant3.Enabled = False
                txt_dx3.Enabled = False
                DDL_fx3.Enabled = False
                txt_uecant3.Enabled = False
                DDL_earv3.Enabled = False
                txt_cant4.Enabled = False
                txt_dx4.Enabled = False
                DDL_fx4.Enabled = False
                txt_uecant4.Enabled = False
                DDL_earv4.Enabled = False
                txt_cant5.Enabled = False
                txt_dx5.Enabled = False
                DDL_fx5.Enabled = False
                txt_uecant5.Enabled = False
                DDL_earv5.Enabled = False
                txt_cant6.Enabled = False
                txt_dx6.Enabled = False
                DDL_fx6.Enabled = False
                txt_uecant6.Enabled = False
                DDL_earv6.Enabled = False
                txt_cant7.Enabled = False
                txt_dx7.Enabled = False
                DDL_fx7.Enabled = False
                txt_uecant7.Enabled = False
                DDL_earv7.Enabled = False
                txt_cant8.Enabled = False
                txt_dx8.Enabled = False
                DDL_fx8.Enabled = False
                txt_uecant8.Enabled = False
                DDL_earv8.Enabled = False
                txt_devcant1.Enabled = False
                txt_devcant2.Enabled = False
                txt_devcant3.Enabled = False
                txt_devcant4.Enabled = False
                txt_devcant5.Enabled = False
                txt_devcant6.Enabled = False
                txt_devcant7.Enabled = False
                txt_devcant8.Enabled = False
                txt_fr_dd.Enabled = False
                txt_fr_mm.Enabled = False
                txt_fr_yy.Enabled = False
                txt_tarvdias.Enabled = False
                CB_citaFx.Enabled = False
                CB_citaMx.Enabled = False
                DDL_embarazo.Enabled = False
                txt_retornodias.Enabled = False
                txt_adherencia.Enabled = False
                txt_observaciones.Enabled = False
                txt_cd4.Enabled = False
                txt_cv.Enabled = False
                DDL_cod1.Enabled = False
                DDL_cod2.Enabled = False
                DDL_cod3.Enabled = False
                DDL_cod4.Enabled = False
                DDL_cod5.Enabled = False
                DDL_cod6.Enabled = False
                DDL_cod7.Enabled = False
                DDL_cod8.Enabled = False

                txt_cant1P.Enabled = False
                txt_dx1P.Enabled = False
                DDL_fx1P.Enabled = False
                DDL_earv1P.Enabled = False
                txt_cant2P.Enabled = False
                txt_dx2P.Enabled = False
                DDL_fx2P.Enabled = False
                DDL_earv2P.Enabled = False
                txt_cant3P.Enabled = False
                txt_dx3P.Enabled = False
                DDL_fx3P.Enabled = False
                DDL_earv3P.Enabled = False
                txt_cant4P.Enabled = False
                txt_dx4P.Enabled = False
                DDL_fx4P.Enabled = False
                DDL_earv4P.Enabled = False
                txt_devcant1P.Enabled = False
                txt_devcant2P.Enabled = False
                txt_devcant3P.Enabled = False
                txt_devcant4P.Enabled = False
                txt_fr_ddP.Enabled = False
                txt_fr_mmP.Enabled = False
                txt_fr_yyP.Enabled = False
                txt_tarvdiasP.Enabled = False
                CB_citaFxP.Enabled = False
                CB_citaMxP.Enabled = False
                DDL_embarazoP.Enabled = False
                txt_retornodiasP.Enabled = False
                txt_observacionesP.Enabled = False
                txt_cd4P.Enabled = False
                txt_cvP.Enabled = False
                DDL_cod1P.Enabled = False
                DDL_cod2P.Enabled = False
                DDL_cod3P.Enabled = False
                DDL_cod4P.Enabled = False
        End Select
    End Sub

    Sub llenadatos(ByVal nhc As String)
        Dim tipo As String
        If nhc.Substring(1, 1).ToUpper.ToString() = "P" Then
            tipo = "P"
        Else
            tipo = "A"
        End If
        If tipo = "A" Then
            db.Cn2 = cn2
            Dim x As String = db.ObtieneBasales(nhc, usuario)
            Dim rp As String() = x.Split("|")
            If rp(0).ToString() = "True" Then
                strnhc = nhc
                Session("nhc") = nhc
                existenhc = True
                lbl_asi.Text = nhc
                lbl_genero.Text = String.Empty
                lbl_nombre.Text = String.Empty
                lbl_telefono.Text = String.Empty
                lbl_nacimiento.Text = String.Empty
                lbl_domicilio.Text = String.Empty
                lbl_estatus.Text = String.Empty
                lbl_genero.Text = rp(1).ToString()
                lbl_nombre.Text = rp(2).ToString()
                lbl_telefono.Text = rp(3).ToString()
                lbl_nacimiento.Text = rp(4).ToString()
                lbl_domicilio.Text = rp(5).ToString()
                lbl_estatus.Text = rp(6).ToString()
                lbl_error.Text = String.Empty
                'btn_editar.Visible = False
                'btn_agregar.Visible = False
            Else
                lbl_error.Text = rp(1)
                existenhc = False
                'btn_editar.Visible = False
                'btn_agregar.Visible = False
            End If
        ElseIf tipo = "P" Then
            db.Cn1 = cn1
            Dim x As String = db.ObtieneBasalesP(nhc, usuario)
            Dim rpP As String() = x.Split("|")
            If rpP(0).ToString() = "True" Then
                strnhc = nhc
                Session("nhc") = nhc
                existenhc = True
                lbl_asi.Text = nhc
                lbl_genero.Text = String.Empty
                lbl_nombre.Text = String.Empty
                lbl_telefono.Text = String.Empty
                lbl_nacimiento.Text = String.Empty
                lbl_domicilio.Text = String.Empty
                lbl_estatus.Text = String.Empty
                lbl_genero.Text = rpP(1).ToString()
                lbl_nombre.Text = rpP(2).ToString()
                lbl_telefono.Text = rpP(3).ToString()
                lbl_nacimiento.Text = rpP(4).ToString()
                lbl_domicilio.Text = rpP(5).ToString()
                lbl_estatus.Text = rpP(6).ToString()
                lbl_error.Text = String.Empty
                'btn_editar.Visible = True
                'btn_agregar.Visible = False
            Else
                lbl_error.Text = rpP(1)
                existenhc = False
                'btn_editar.Visible = False
                'btn_agregar.Visible = True
            End If
        End If
    End Sub

    Function tip(ByVal estatus As String, ByVal cantidad As String) As String
        Return "Estatus: " & estatus & " - Cantidad: " & cantidad
    End Function

    Function dev(ByVal valor As String) As Boolean
        If valor = String.Empty Then
            Return False
        Else
            Return True
        End If
    End Function

    Sub llenacodigo()
        db.Cn1 = cn1
        usuario = Session("usuario").ToString()
        Dim tbMed As DataTable = db.ObtieneARVMedicamento("1", usuario)
        If tbMed IsNot Nothing Then
            DDL_cod1.DataSource = tbMed
            DDL_cod1.DataTextField = "Codigo"
            DDL_cod1.DataValueField = "IdFFARV"
            DDL_cod1.DataBind()
            DDL_cod1.Items.Insert(0, New ListItem("", "0"))
            DDL_cod2.DataSource = tbMed
            DDL_cod2.DataTextField = "Codigo"
            DDL_cod2.DataValueField = "IdFFARV"
            DDL_cod2.DataBind()
            DDL_cod2.Items.Insert(0, New ListItem("", "0"))
            DDL_cod3.DataSource = tbMed
            DDL_cod3.DataTextField = "Codigo"
            DDL_cod3.DataValueField = "IdFFARV"
            DDL_cod3.DataBind()
            DDL_cod3.Items.Insert(0, New ListItem("", "0"))
            DDL_cod4.DataSource = tbMed
            DDL_cod4.DataTextField = "Codigo"
            DDL_cod4.DataValueField = "IdFFARV"
            DDL_cod4.DataBind()
            DDL_cod4.Items.Insert(0, New ListItem("", "0"))
            DDL_cod5.DataSource = tbMed
            DDL_cod5.DataTextField = "Codigo"
            DDL_cod5.DataValueField = "IdFFARV"
            DDL_cod5.DataBind()
            DDL_cod5.Items.Insert(0, New ListItem("", "0"))
            DDL_cod6.DataSource = tbMed
            DDL_cod6.DataTextField = "Codigo"
            DDL_cod6.DataValueField = "IdFFARV"
            DDL_cod6.DataBind()
            DDL_cod6.Items.Insert(0, New ListItem("", "0"))
            DDL_cod7.DataSource = tbMed
            DDL_cod7.DataTextField = "Codigo"
            DDL_cod7.DataValueField = "IdFFARV"
            DDL_cod7.DataBind()
            DDL_cod7.Items.Insert(0, New ListItem("", "0"))
            DDL_cod8.DataSource = tbMed
            DDL_cod8.DataTextField = "Codigo"
            DDL_cod8.DataValueField = "IdFFARV"
            DDL_cod8.DataBind()
            DDL_cod8.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenacodigoP()
        db.Cn1 = cn1
        usuario = Session("usuario").ToString()
        Dim tbMed As DataTable = db.ObtieneARVMedicamento("2", usuario)
        If tbMed IsNot Nothing Then
            DDL_cod1P.DataSource = tbMed
            DDL_cod1P.DataTextField = "Codigo"
            DDL_cod1P.DataValueField = "IdFFProf"
            DDL_cod1P.DataBind()
            DDL_cod1P.Items.Insert(0, New ListItem("", "0"))
            DDL_cod2P.DataSource = tbMed
            DDL_cod2P.DataTextField = "Codigo"
            DDL_cod2P.DataValueField = "IdFFProf"
            DDL_cod2P.DataBind()
            DDL_cod2P.Items.Insert(0, New ListItem("", "0"))
            DDL_cod3P.DataSource = tbMed
            DDL_cod3P.DataTextField = "Codigo"
            DDL_cod3P.DataValueField = "IdFFProf"
            DDL_cod3P.DataBind()
            DDL_cod3P.Items.Insert(0, New ListItem("", "0"))
            DDL_cod4P.DataSource = tbMed
            DDL_cod4P.DataTextField = "Codigo"
            DDL_cod4P.DataValueField = "IdFFProf"
            DDL_cod4P.DataBind()
            DDL_cod4P.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenafrecuencia()
        db.Cn1 = cn1
        usuario = Session("usuario").ToString()
        Dim tbFx As DataTable = db.ObtieneFrecuenia(usuario)
        If tbFx IsNot Nothing Then
            DDL_fx1.DataSource = tbFx
            DDL_fx1.DataTextField = "IdFrecuencia"
            DDL_fx1.DataValueField = "IdFrecuencia"
            DDL_fx1.DataBind()
            DDL_fx1.Items.Insert(0, New ListItem("", "0"))
            DDL_fx2.DataSource = tbFx
            DDL_fx2.DataTextField = "IdFrecuencia"
            DDL_fx2.DataValueField = "IdFrecuencia"
            DDL_fx2.DataBind()
            DDL_fx2.Items.Insert(0, New ListItem("", "0"))
            DDL_fx3.DataSource = tbFx
            DDL_fx3.DataTextField = "IdFrecuencia"
            DDL_fx3.DataValueField = "IdFrecuencia"
            DDL_fx3.DataBind()
            DDL_fx3.Items.Insert(0, New ListItem("", "0"))
            DDL_fx4.DataSource = tbFx
            DDL_fx4.DataTextField = "IdFrecuencia"
            DDL_fx4.DataValueField = "IdFrecuencia"
            DDL_fx4.DataBind()
            DDL_fx4.Items.Insert(0, New ListItem("", "0"))
            DDL_fx5.DataSource = tbFx
            DDL_fx5.DataTextField = "IdFrecuencia"
            DDL_fx5.DataValueField = "IdFrecuencia"
            DDL_fx5.DataBind()
            DDL_fx5.Items.Insert(0, New ListItem("", "0"))
            DDL_fx6.DataSource = tbFx
            DDL_fx6.DataTextField = "IdFrecuencia"
            DDL_fx6.DataValueField = "IdFrecuencia"
            DDL_fx6.DataBind()
            DDL_fx6.Items.Insert(0, New ListItem("", "0"))
            DDL_fx7.DataSource = tbFx
            DDL_fx7.DataTextField = "IdFrecuencia"
            DDL_fx7.DataValueField = "IdFrecuencia"
            DDL_fx7.DataBind()
            DDL_fx7.Items.Insert(0, New ListItem("", "0"))
            DDL_fx8.DataSource = tbFx
            DDL_fx8.DataTextField = "IdFrecuencia"
            DDL_fx8.DataValueField = "IdFrecuencia"
            DDL_fx8.DataBind()
            DDL_fx8.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenafrecuenciaP()
        db.Cn1 = cn1
        usuario = Session("usuario").ToString()
        Dim tbFx As DataTable = db.ObtieneFrecuenia(usuario)
        If tbFx IsNot Nothing Then
            DDL_fx1P.DataSource = tbFx
            DDL_fx1P.DataTextField = "IdFrecuencia"
            DDL_fx1P.DataValueField = "IdFrecuencia"
            DDL_fx1P.DataBind()
            DDL_fx1P.Items.Insert(0, New ListItem("", "0"))
            DDL_fx2P.DataSource = tbFx
            DDL_fx2P.DataTextField = "IdFrecuencia"
            DDL_fx2P.DataValueField = "IdFrecuencia"
            DDL_fx2P.DataBind()
            DDL_fx2P.Items.Insert(0, New ListItem("", "0"))
            DDL_fx3P.DataSource = tbFx
            DDL_fx3P.DataTextField = "IdFrecuencia"
            DDL_fx3P.DataValueField = "IdFrecuencia"
            DDL_fx3P.DataBind()
            DDL_fx3P.Items.Insert(0, New ListItem("", "0"))
            DDL_fx4P.DataSource = tbFx
            DDL_fx4P.DataTextField = "IdFrecuencia"
            DDL_fx4P.DataValueField = "IdFrecuencia"
            DDL_fx4P.DataBind()
            DDL_fx4P.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenaEstatus()
        db.Cn1 = cn1
        usuario = Session("usuario").ToString()
        Dim tbE As DataTable = db.ObtieneEstatus(usuario)
        If tbE IsNot Nothing Then
            DDL_earv1.DataSource = tbE
            DDL_earv1.DataTextField = "Codigo"
            DDL_earv1.DataValueField = "IdEstatus"
            DDL_earv1.DataBind()
            DDL_earv1.Items.Insert(0, New ListItem("", "0"))
            DDL_earv2.DataSource = tbE
            DDL_earv2.DataTextField = "Codigo"
            DDL_earv2.DataValueField = "IdEstatus"
            DDL_earv2.DataBind()
            DDL_earv2.Items.Insert(0, New ListItem("", "0"))
            DDL_earv3.DataSource = tbE
            DDL_earv3.DataTextField = "Codigo"
            DDL_earv3.DataValueField = "IdEstatus"
            DDL_earv3.DataBind()
            DDL_earv3.Items.Insert(0, New ListItem("", "0"))
            DDL_earv4.DataSource = tbE
            DDL_earv4.DataTextField = "Codigo"
            DDL_earv4.DataValueField = "IdEstatus"
            DDL_earv4.DataBind()
            DDL_earv4.Items.Insert(0, New ListItem("", "0"))
            DDL_earv5.DataSource = tbE
            DDL_earv5.DataTextField = "Codigo"
            DDL_earv5.DataValueField = "IdEstatus"
            DDL_earv5.DataBind()
            DDL_earv5.Items.Insert(0, New ListItem("", "0"))
            DDL_earv6.DataSource = tbE
            DDL_earv6.DataTextField = "Codigo"
            DDL_earv6.DataValueField = "IdEstatus"
            DDL_earv6.DataBind()
            DDL_earv6.Items.Insert(0, New ListItem("", "0"))
            DDL_earv7.DataSource = tbE
            DDL_earv7.DataTextField = "Codigo"
            DDL_earv7.DataValueField = "IdEstatus"
            DDL_earv7.DataBind()
            DDL_earv7.Items.Insert(0, New ListItem("", "0"))
            DDL_earv8.DataSource = tbE
            DDL_earv8.DataTextField = "Codigo"
            DDL_earv8.DataValueField = "IdEstatus"
            DDL_earv8.DataBind()
            DDL_earv8.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenaEstatusP()
        db.Cn1 = cn1
        usuario = Session("usuario").ToString()
        Dim tbE As DataTable = db.ObtieneEstatus(usuario)
        If tbE IsNot Nothing Then
            DDL_earv1P.DataSource = tbE
            DDL_earv1P.DataTextField = "Codigo"
            DDL_earv1P.DataValueField = "IdEstatus"
            DDL_earv1P.DataBind()
            DDL_earv1P.Items.Insert(0, New ListItem("", "0"))
            DDL_earv2P.DataSource = tbE
            DDL_earv2P.DataTextField = "Codigo"
            DDL_earv2P.DataValueField = "IdEstatus"
            DDL_earv2P.DataBind()
            DDL_earv2P.Items.Insert(0, New ListItem("", "0"))
            DDL_earv3P.DataSource = tbE
            DDL_earv3P.DataTextField = "Codigo"
            DDL_earv3P.DataValueField = "IdEstatus"
            DDL_earv3P.DataBind()
            DDL_earv3P.Items.Insert(0, New ListItem("", "0"))
            DDL_earv4P.DataSource = tbE
            DDL_earv4P.DataTextField = "Codigo"
            DDL_earv4P.DataValueField = "IdEstatus"
            DDL_earv4P.DataBind()
            DDL_earv4P.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenaEmbarazo()
        db.Cn1 = cn1
        Dim tbEmb As DataTable = db.ObtieneEmbarazo(usuario)
        If tbEmb IsNot Nothing Then
            DDL_embarazo.DataSource = tbEmb
            DDL_embarazo.DataTextField = "IdEmbarazo"
            DDL_embarazo.DataValueField = "IdEmbarazo"
            DDL_embarazo.DataBind()
            DDL_embarazo.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    Sub llenaEmbarazoP()
        db.Cn1 = cn1
        Dim tbEmb As DataTable = db.ObtieneEmbarazo(usuario)
        If tbEmb IsNot Nothing Then
            DDL_embarazoP.DataSource = tbEmb
            DDL_embarazoP.DataTextField = "IdEmbarazo"
            DDL_embarazoP.DataValueField = "IdEmbarazo"
            DDL_embarazoP.DataBind()
            DDL_embarazoP.Items.Insert(0, New ListItem("", "0"))
        End If
    End Sub

    'Protected Sub txt_asi_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_asi.TextChanged
    '    buscaNHC()
    'End Sub

    Protected Sub DDL_cod1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod1.SelectedIndexChanged
        If DDL_cod1.SelectedValue <> "0" Then
            txt_cant1.Enabled = True
            txt_dx1.Enabled = True
            DDL_fx1.Enabled = True
            txt_uecant1.Enabled = True
            DDL_earv1.Enabled = True
            txt_cant1.Focus()
        Else
            setcampos(1)
            DDL_fx1.SelectedValue = 0
            DDL_earv1.SelectedValue = 0
            DDL_cod1.Focus()
        End If
    End Sub

    Protected Sub DDL_cod2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod2.SelectedIndexChanged
        If DDL_cod2.SelectedValue <> "0" Then
            txt_cant2.Enabled = True
            txt_dx2.Enabled = True
            DDL_fx2.Enabled = True
            txt_uecant2.Enabled = True
            DDL_earv2.Enabled = True
            txt_cant2.Focus()
        Else
            setcampos(2)
            DDL_fx2.SelectedValue = 0
            DDL_earv2.SelectedValue = 0
            DDL_cod2.Focus()
        End If
    End Sub

    Protected Sub DDL_cod3_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod3.SelectedIndexChanged
        If DDL_cod3.SelectedValue <> "0" Then
            txt_cant3.Enabled = True
            txt_dx3.Enabled = True
            DDL_fx3.Enabled = True
            txt_uecant3.Enabled = True
            DDL_earv3.Enabled = True
            txt_cant3.Focus()
        Else
            setcampos(3)
            DDL_fx3.SelectedValue = 0
            DDL_earv3.SelectedValue = 0
            DDL_cod3.Focus()
        End If
    End Sub

    Protected Sub DDL_cod4_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod4.SelectedIndexChanged
        If DDL_cod4.SelectedValue <> "0" Then
            txt_cant4.Enabled = True
            txt_dx4.Enabled = True
            DDL_fx4.Enabled = True
            txt_uecant4.Enabled = True
            DDL_earv4.Enabled = True
            txt_cant4.Focus()
        Else
            setcampos(4)
            DDL_fx4.SelectedValue = 0
            DDL_earv4.SelectedValue = 0
            DDL_cod4.Focus()
        End If
    End Sub

    Protected Sub DDL_cod5_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod5.SelectedIndexChanged
        If DDL_cod5.SelectedValue <> "0" Then
            txt_cant5.Enabled = True
            txt_dx5.Enabled = True
            DDL_fx5.Enabled = True
            txt_uecant5.Enabled = True
            DDL_earv5.Enabled = True
            txt_cant5.Focus()
        Else
            setcampos(5)
            DDL_fx5.SelectedValue = 0
            DDL_earv5.SelectedValue = 0
            DDL_cod5.Focus()
        End If
    End Sub

    Protected Sub DDL_cod6_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod6.SelectedIndexChanged
        If DDL_cod6.SelectedValue <> "0" Then
            txt_cant6.Enabled = True
            txt_dx6.Enabled = True
            DDL_fx6.Enabled = True
            txt_uecant6.Enabled = True
            DDL_earv6.Enabled = True
            txt_cant6.Focus()
        Else
            setcampos(6)
            DDL_fx6.SelectedValue = 0
            DDL_earv6.SelectedValue = 0
            DDL_cod6.Focus()
        End If
    End Sub

    Protected Sub DDL_cod7_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod7.SelectedIndexChanged
        If DDL_cod7.SelectedValue <> "0" Then
            txt_cant7.Enabled = True
            txt_dx7.Enabled = True
            DDL_fx7.Enabled = True
            txt_uecant7.Enabled = True
            DDL_earv7.Enabled = True
            txt_cant7.Focus()
        Else
            setcampos(7)
            DDL_fx7.SelectedValue = 0
            DDL_earv7.SelectedValue = 0
            DDL_cod7.Focus()
        End If
    End Sub

    Protected Sub DDL_cod8_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDL_cod8.SelectedIndexChanged
        If DDL_cod8.SelectedValue <> "0" Then
            txt_cant8.Enabled = True
            txt_dx8.Enabled = True
            DDL_fx8.Enabled = True
            txt_uecant8.Enabled = True
            DDL_earv8.Enabled = True
            txt_cant8.Focus()
        Else
            setcampos(8)
            DDL_fx8.SelectedValue = 0
            DDL_earv8.SelectedValue = 0
            DDL_cod8.Focus()
        End If
    End Sub

    Protected Sub btn_grabar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_grabar.Click
        ''NHC, FechaEntrega, Med1_Codigo, Med1_Cantidad, Med1_Dosis, Med1_Frecuencia, Med1_UExCantidad, Med1_ARVEstatus, Med2_Codigo, Med2_Cantidad, Med2_Dosis, Med2_Frecuencia, Med2_UExCantidad, Med2_ARVEstatus, Med3_Codigo, Med3_Cantidad, Med3_Dosis, Med3_Frecuencia, Med3_UExCantidad, Med3_ARVEstatus, Med4_Codigo, Med4_Cantidad, Med4_Dosis, Med4_Frecuencia, Med4_UExCantidad, Med4_ARVEstatus, FechaRetorno, TiempoTARV, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, CD4, CV, Observaciones
        'Dim FechaEntrega As String = Convert.ToString(txt_fe_dd.Text) + "/" + Convert.ToString(txt_fe_mm.Text) + "/" + Convert.ToString(txt_fe_yy.Text)
        'Dim FechaRetorno As String = Convert.ToString(txt_fr_dd.Text) + "/" + Convert.ToString(txt_fr_mm.Text) + "/" + Convert.ToString(txt_fr_yy.Text)
        'Dim CitaMx As String
        'If CB_citaMx.Checked Then
        '    CitaMx = "1"
        'Else
        '    CitaMx = "2"
        'End If
        'Dim CitaFx As String
        'If CB_citaFx.Checked Then
        '    CitaFx = "1"
        'Else
        '    CitaFx = "2"
        'End If
        'If Session("nhc").ToString() = String.Empty Or Session("nhc").ToString() = "" Then
        '    Session("nhc") = lbl_asi.Text.ToUpper()
        'End If
        'Dim datos As String = Session("nhc").ToString() + "|" + FechaEntrega + "|" + DDL_cod1.SelectedValue.ToString() + "|" + str(txt_cant1.Text.ToString()) + "|" + txt_dx1.Text.ToString() + "|" + DDL_fx1.SelectedValue.ToString() + "|" + str(txt_uecant1.Text.ToString()) + "|" + DDL_earv1.SelectedValue.ToString() + "|" + DDL_cod2.SelectedValue.ToString() + "|" + str(txt_cant2.Text.ToString()) + "|" + txt_dx2.Text.ToString() + "|" + DDL_fx2.SelectedValue.ToString() + "|" + str(txt_uecant2.Text.ToString()) + "|" + DDL_earv2.SelectedValue.ToString() + "|" + DDL_cod3.SelectedValue.ToString() + "|" + str(txt_cant3.Text.ToString()) + "|" + txt_dx3.Text.ToString() + "|" + DDL_fx3.SelectedValue.ToString() + "|" + str(txt_uecant3.Text.ToString()) + "|" + DDL_earv3.SelectedValue.ToString() + "|" + DDL_cod4.SelectedValue.ToString() + "|" + str(txt_cant4.Text.ToString()) + "|" + txt_dx4.Text.ToString() + "|" + DDL_fx4.SelectedValue.ToString() + "|" + str(txt_uecant4.Text.ToString()) + "|" + DDL_earv4.SelectedValue.ToString() + "|" + FechaRetorno + "|" + str(txt_tarvdias.Text.ToString()) + "|" + CitaMx + "|" + CitaFx + "|" + DDL_embarazo.SelectedValue.ToString() + "|" + str(txt_retornodias.Text.ToString()) + "|" + txt_cd4.Text.ToString() + "|" + txt_cv.Text.ToString() + "|" + txt_observaciones.Text.ToString()
        'db.Cn1 = cn1
        'ufecha = Session("ufecha")
        'If ufecha Then
        '    Dim ufdatos As String = Session("idufecha").ToString() + "|" + str(txt_devcant1.Text.ToString()) + "|" + str(txt_devcant2.Text.ToString()) + "|" + str(txt_devcant3.Text.ToString()) + "|" + str(txt_devcant4.Text.ToString()) + "|" + str(txt_adherencia.Text.ToString())
        '    db.GrabaUFechaControlARV(ufdatos, usuario)
        'End If
        'db.GrabaControlARV(datos, usuario)
        'Response.Redirect("~/ingresoARV.aspx", False)
    End Sub

    Function str(ByVal x As String) As String
        Dim z As String
        If x = String.Empty Then
            z = "NULL"
        Else
            z = x
        End If
        Return z
    End Function

    Protected Sub GV_regPacA_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GV_regPacA.RowCommand
        If e.CommandName = "Editar" Then
            Try
                Dim gv As GridView = DirectCast(sender, GridView)
                Dim rowIndex As Int32 = Convert.ToInt32(e.CommandArgument.ToString())
                Dim id As String = gv.DataKeys(rowIndex)(0).ToString()
                Dim nhc As String = gv.DataKeys(rowIndex)(1).ToString()
                setcampos(0)
                llenacodigo()
                llenafrecuencia()
                llenaEstatus()
                llenaEmbarazo()
                llenaregistro(id)
                divARV.Visible = True
                divProf.Visible = False
                MPERegistro.Show()
            Catch ex As Exception
                lbl_error.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub GV_regPacA_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GV_regPacA.PreRender
        Dim n As Integer = 0
        For Each nrow As GridViewRow In GV_regPacA.Rows
            For columnIndex As Integer = n To Convert.ToInt32(GV_regPacA.Rows.Count)
                Dim irow1 As ImageButton = DirectCast(nrow.FindControl("IB_editar"), ImageButton)
                irow1.CommandArgument = Convert.ToString(n)
            Next
            n += 1
        Next
    End Sub

    Protected Sub GV_regPacP_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GV_regPacP.RowCommand
        If e.CommandName = "Editar" Then
            Try
                Dim gv As GridView = DirectCast(sender, GridView)
                Dim rowIndex As Int32 = Convert.ToInt32(e.CommandArgument.ToString())
                Dim id As String = gv.DataKeys(rowIndex)(0).ToString()
                Dim nhc As String = gv.DataKeys(rowIndex)(1).ToString()
                'Response.Redirect("~/ConsultaARV.aspx?id=" + id + "&nhc=" + nhc, False)
                setcampos(0)
                llenacodigoP()
                llenafrecuenciaP()
                llenaEstatusP()
                llenaEmbarazoP()
                llenaregistroP(id)
                divARV.Visible = False
                divProf.Visible = True
                MPERegistro.Show()
            Catch ex As Exception
                lbl_error.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub GV_regPacP_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GV_regPacP.PreRender
        Dim n As Integer = 0
        For Each nrow As GridViewRow In GV_regPacP.Rows
            For columnIndex As Integer = n To Convert.ToInt32(GV_regPacP.Rows.Count)
                Dim irow1 As ImageButton = DirectCast(nrow.FindControl("IB_editar"), ImageButton)
                irow1.CommandArgument = Convert.ToString(n)
            Next
            n += 1
        Next
    End Sub

    'Protected Sub btn_buscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_buscar.Click
    '    buscaNHC()
    'End Sub

    'Sub buscaNHC()
    '    If txt_asi.Text.Trim <> String.Empty Then
    '        llenadatos(txt_asi.Text.ToUpper())
    '        If existenhc Then
    '            If ufecha Then
    '                divingreso.Visible = True
    '                txt_devcant1.Focus()
    '            Else
    '                divingreso.Visible = True
    '                txt_fe_dd.Focus()
    '            End If
    '        Else
    '            lbl_genero.Text = String.Empty
    '            lbl_nombre.Text = String.Empty
    '            lbl_telefono.Text = String.Empty
    '            lbl_nacimiento.Text = String.Empty
    '            lbl_domicilio.Text = String.Empty
    '            lbl_estatus.Text = String.Empty
    '            divingreso.Visible = False
    '            txt_asi.Focus()
    '        End If
    '    Else
    '        lbl_genero.Text = String.Empty
    '        lbl_nombre.Text = String.Empty
    '        lbl_telefono.Text = String.Empty
    '        lbl_nacimiento.Text = String.Empty
    '        lbl_domicilio.Text = String.Empty
    '        lbl_estatus.Text = String.Empty
    '        divingreso.Visible = False
    '        txt_asi.Focus()
    '    End If
    'End Sub

    'Protected Sub btn_editar_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btn_editar.Click
    '    Response.Redirect("~/EBPediatrico.aspx?nhc=" + txt_asi.Text.Trim.ToUpper(), False)
    'End Sub

    'Protected Sub btn_agregar_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btn_agregar.Click
    '    Response.Redirect("~/NBPediatrico.aspx", False)
    'End Sub
End Class
