﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data

Public Class BusinessLogicDB
    Private _cn1 As String
    Private _cn2 As String
    Private _error As String
    Private _page As String = ""
    Private _pageO As String = ""
    Private Const TimeoutDB As Integer = 120

    Public Property PageName() As String
        Get
            Return _page
        End Get
        Set(ByVal value As String)
            _page = value
        End Set
    End Property

    Public ReadOnly Property DB_Error() As String
        Get
            Return _error
        End Get
    End Property

    Public Property Cn1() As String
        Get
            Return _cn1
        End Get
        Set(ByVal value As String)
            _cn1 = value
        End Set
    End Property

    Public Property Cn2() As String
        Get
            Return _cn2
        End Get
        Set(ByVal value As String)
            _cn2 = value
        End Set
    End Property

    '*Login, cifrador y decifrador*//

    Public Function LoginValidation(ByVal UserName As String, ByVal Password As String) As String
        _page = "LoginValidation"
        Dim x As String = ""
        Dim claveE As String = Encriptar(Password, "Acuario") 'EncString(Password)
        Try
            Using connection As New SqlConnection(_cn2)
                connection.Open()
                Dim strSQL As String = String.Format("SELECT IdUsuario, NomUsuario, Perfil, Clave FROM USUARIO WHERE NomUsuario = '{0}'", UserName)
                Dim command As New SqlCommand(strSQL, connection)
                Dim Dr As SqlDataReader = Nothing
                Dr = command.ExecuteReader()
                If Dr.HasRows Then
                    While Dr.Read()
                        If claveE = Dr("Clave").ToString() Then
                            x = "True|" & Dr("IdUsuario").ToString() & "|" & Dr("NomUsuario").ToString() & "|" & Dr("Perfil").ToString()
                            Exit While
                        Else
                            x = "False|Usuario o Clave Incorrectos, favor intente de Nuevo."
                        End If
                    End While
                Else
                    x = "False|Usuario o Clave Incorrectos, favor intente de Nuevo."
                End If
                Dr.Close()
            End Using
            Return x
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(UserName & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            x = "False|Hubo un Error al Iniciar Sesion, intente de nuevo."
            Return x
        End Try
    End Function

    Public Function ConvertirClave(ByVal sOriginal As String, ByVal sClave As String, ByVal vAccion As Boolean) As String
        Dim x As String = ""
        Dim LenOri As Long
        Dim LenClave As Long
        Dim i As Long
        Dim j As Long
        Dim cO As Long
        Dim cC As Long
        Dim k As Long
        Dim v As String

        LenOri = Len(sOriginal)
        LenClave = Len(sClave)

        v = Space(LenOri)
        i = 0
        For j = 1 To LenOri
            i = i + 1
            If i > LenClave Then
                i = 1
            End If
            cO = Asc(Mid(sOriginal, j, 1))
            cC = Asc(Mid(sClave, i, 1))
            If vAccion Then
                k = cO + cC
                If k > 255 Then
                    k = k - 255
                End If
            Else
                k = cO - cC
                If k < 0 Then
                    k = k + 255
                End If
            End If
            Mid(v, j, 1) = Chr(k)
        Next
        ConvertirClave = v
    End Function

    Public Function DesEncriptar(ByVal sOriginal As String, ByVal sClave As String) As String
        DesEncriptar = ConvertirClave(sOriginal, sClave, False)
    End Function

    Public Function Encriptar(ByVal sOriginal As String, ByVal sClave As String) As String
        Encriptar = ConvertirClave(sOriginal, sClave, True)
    End Function

    Public Sub GrabaSesion(ByVal id As String, ByVal tipo As String, ByVal ip As String, ByVal usuario As String)
        _page = "db.GrabaSesion"
        Dim sql As String = String.Format("INSERT INTO UActividad (IdUsuario, Tipo, IP) VALUES({0}, '{1}', '{2}')", id, tipo, ip)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Function Desconectar(ByVal id As String, ByVal ip As String, ByVal usuario As String) As Boolean
        _page = "db.Desconectar"
        Dim sql As String = String.Format("INSERT INTO UActividad (IdUsuario, Tipo, IP) VALUES({0}, '{1}', '{2}')", id, "O", ip)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return True
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Return False
        End Try
    End Function

    '*Lista Pacientes*//
    Public Function ListaPacientes(ByVal tipo As String, ByVal estatus As String, ByVal usuario As String) As DataTable
        _page = "db.ListaPacientes"
        Dim Query As String = ""
        If tipo = "A" Then
            Select Case estatus
                Case Is = "AC"
                    'todos los pacientes adultos activos
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'A' AND ME NOT IN (6, 7, 12)"
                Case Is = "AB"
                    'todos los pacientes adultos abandonos
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'A' AND ME = 6"
                Case Is = "TR"
                    'todos los pacientes adultos traslados		
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'A' AND ME = 7"
                Case Is = "FA"
                    'todos los pacientes adultos fallecidos		
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'A' AND ME = 12"
            End Select
        ElseIf tipo = "P" Then
            Select Case estatus
                Case Is = "AC"
                    'todos los pacientes pediatria activos	
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'P' AND ME NOT IN (6, 7, 12)"
                Case Is = "AB"
                    'todos los pacientes pediatria abandonos		
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'P' AND ME = 6"
                Case Is = "TR"
                    'todos los pacientes pediatria traslados		
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'P' AND ME = 7"
                Case Is = "FA"
                    'todos los pacientes pediatria fallecidos		
                    Query = "SELECT NHC, Cohorte, Paciente, UltimaFechaEntrega, FechaRetorno, Dias FROM v_ListaPacientes WHERE TIPO = 'P' AND ME = 12"
            End Select
        End If

        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    Public Function RegistrosPacienteARV(ByVal nhc As String, ByVal usuario As String) As DataTable
        _page = "db.RegistrosPacienteARV"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Q.Append("SELECT NHC,IdCCARV,CONVERT(DATE,FechaEntrega) AS 'FechaEntrega',dbo.fn_ObtieneCodMed('A', Med1_Codigo) AS 'M1C',Med1_Cantidad AS 'M1N',dbo.fn_ObtieneEstatusMed(Med1_ARVEstatus) AS 'M1E', ")
        Q.Append("dbo.fn_ObtieneCodMed('A', Med2_Codigo) AS 'M2C',Med2_Cantidad AS 'M2N',dbo.fn_ObtieneEstatusMed(Med2_ARVEstatus) AS 'M2E',dbo.fn_ObtieneCodMed('A', Med3_Codigo) AS 'M3C',Med3_Cantidad AS 'M3N',dbo.fn_ObtieneEstatusMed(Med3_ARVEstatus) AS 'M3E', ")
        Q.Append("dbo.fn_ObtieneCodMed('A', Med4_Codigo) AS 'M4C',Med4_Cantidad AS 'M4N',dbo.fn_ObtieneEstatusMed(Med4_ARVEstatus) AS 'M4E',dbo.fn_ObtieneCodMed('A', Med5_Codigo) AS 'M5C',Med5_Cantidad AS 'M5N',dbo.fn_ObtieneEstatusMed(Med5_ARVEstatus) AS 'M5E', ")
        Q.Append("dbo.fn_ObtieneCodMed('A', Med6_Codigo) AS 'M6C',Med6_Cantidad AS 'M6N',dbo.fn_ObtieneEstatusMed(Med6_ARVEstatus) AS 'M6E',dbo.fn_ObtieneCodMed('A', Med7_Codigo) AS 'M7C',Med7_Cantidad AS 'M7N',dbo.fn_ObtieneEstatusMed(Med7_ARVEstatus) AS 'M7E', ")
        Q.Append("dbo.fn_ObtieneCodMed('A', Med8_Codigo) AS 'M8C',Med8_Cantidad AS 'M8N',dbo.fn_ObtieneEstatusMed(Med8_ARVEstatus) AS 'M8E',CONVERT(DATE,FechaRetorno) AS 'FechaRetorno',TiempoTARV,Embarazo,CD4,CV ")
        Q.Append("FROM ControlARV ")
        Q.Append("WHERE NHC = '" & nhc & "' ")
        Q.Append("ORDER BY CONVERT(DATE,FechaRetorno) DESC")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    Public Function ObtieneRegARV(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ObtieneRegARV"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT IdCCARV, FechaEntrega, Med1_Codigo, Med1_Cantidad, Med1_Dosis, Med1_Frecuencia, Med1_UExCantidad, Med1_ARVEstatus, Med1_DevCantidad, ")
        Q.Append("Med2_Codigo, Med2_Cantidad, Med2_Dosis, Med2_Frecuencia, Med2_UExCantidad, Med2_ARVEstatus, Med2_DevCantidad, ")
        Q.Append("Med3_Codigo, Med3_Cantidad, Med3_Dosis, Med3_Frecuencia, Med3_UExCantidad, Med3_ARVEstatus, Med3_DevCantidad, ")
        Q.Append("Med4_Codigo, Med4_Cantidad, Med4_Dosis, Med4_Frecuencia, Med4_UExCantidad, Med4_ARVEstatus, Med4_DevCantidad, ")
        Q.Append("Med5_Codigo, Med5_Cantidad, Med5_Dosis, Med5_Frecuencia, Med5_UExCantidad, Med5_ARVEstatus, Med5_DevCantidad, ")
        Q.Append("Med6_Codigo, Med6_Cantidad, Med6_Dosis, Med6_Frecuencia, Med6_UExCantidad, Med6_ARVEstatus, Med6_DevCantidad, ")
        Q.Append("Med7_Codigo, Med7_Cantidad, Med7_Dosis, Med7_Frecuencia, Med7_UExCantidad, Med7_ARVEstatus, Med7_DevCantidad, ")
        Q.Append("Med8_Codigo, Med8_Cantidad, Med8_Dosis, Med8_Frecuencia, Med8_UExCantidad, Med8_ARVEstatus, Med8_DevCantidad, ")
        Q.Append("FechaRetorno, TiempoTARV, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, Adherencia, CD4, CV, Observaciones ")
        Q.Append("FROM ControlARV ")
        Q.Append("WHERE IdCCARV = " & id)
        Query = Q.ToString()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdCCARV").ToString() + "|" + reader("FechaEntrega").ToString() + "|" + reader("Med1_Codigo").ToString() + "|" + reader("Med1_Cantidad").ToString() + "|" + reader("Med1_Dosis").ToString() + "|" + reader("Med1_Frecuencia").ToString() + "|" + reader("Med1_UExCantidad").ToString() + "|" + reader("Med1_ARVEstatus").ToString() + "|" + reader("Med1_DevCantidad").ToString() + "|" + reader("Med2_Codigo").ToString() + "|" + reader("Med2_Cantidad").ToString() + "|" + reader("Med2_Dosis").ToString() + "|" + reader("Med2_Frecuencia").ToString() + "|" + reader("Med2_UExCantidad").ToString() + "|" + reader("Med2_ARVEstatus").ToString() + "|" + reader("Med2_DevCantidad").ToString() + "|" + reader("Med3_Codigo").ToString() + "|" + reader("Med3_Cantidad").ToString() + "|" + reader("Med3_Dosis").ToString() + "|" + reader("Med3_Frecuencia").ToString() + "|" + reader("Med3_UExCantidad").ToString() + "|" + reader("Med3_ARVEstatus").ToString() + "|" + reader("Med3_DevCantidad").ToString() + "|" + reader("Med4_Codigo").ToString() + "|" + reader("Med4_Cantidad").ToString() + "|" + reader("Med4_Dosis").ToString() + "|" + reader("Med4_Frecuencia").ToString() + "|" + reader("Med4_UExCantidad").ToString() + "|" + reader("Med4_ARVEstatus").ToString() + "|" + reader("Med4_DevCantidad").ToString() + "|" + reader("Med5_Codigo").ToString() + "|" + reader("Med5_Cantidad").ToString() + "|" + reader("Med5_Dosis").ToString() + "|" + reader("Med5_Frecuencia").ToString() + "|" + reader("Med5_UExCantidad").ToString() + "|" + reader("Med5_ARVEstatus").ToString() + "|" + reader("Med5_DevCantidad").ToString() + "|" + reader("Med6_Codigo").ToString() + "|" + reader("Med6_Cantidad").ToString() + "|" + reader("Med6_Dosis").ToString() + "|" + reader("Med6_Frecuencia").ToString() + "|" + reader("Med6_UExCantidad").ToString() + "|" + reader("Med6_ARVEstatus").ToString() + "|" + reader("Med6_DevCantidad").ToString() + "|" + reader("Med7_Codigo").ToString() + "|" + reader("Med7_Cantidad").ToString() + "|" + reader("Med7_Dosis").ToString() + "|" + reader("Med7_Frecuencia").ToString() + "|" + reader("Med7_UExCantidad").ToString() + "|" + reader("Med7_ARVEstatus").ToString() + "|" + reader("Med7_DevCantidad").ToString() + "|" + reader("Med8_Codigo").ToString() + "|" + reader("Med8_Cantidad").ToString() + "|" + reader("Med8_Dosis").ToString() + "|" + reader("Med8_Frecuencia").ToString() + "|" + reader("Med8_UExCantidad").ToString() + "|" + reader("Med8_ARVEstatus").ToString() + "|" + reader("Med8_DevCantidad").ToString() + "|" + reader("FechaRetorno").ToString() + "|" + reader("TiempoTARV").ToString() + "|" + reader("CitaMedica").ToString() + "|" + reader("CitaFarmacia").ToString() + "|" + reader("Embarazo").ToString() + "|" + reader("TiempoRetorno").ToString() + "|" + reader("Adherencia").ToString() + "|" + reader("CD4").ToString() + "|" + reader("CV").ToString() + "|" + reader("Observaciones")
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No se Encontró Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function RegistrosPacienteProf(ByVal nhc As String, ByVal usuario As String) As DataTable
        _page = "db.RegistrosPacienteProf"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Q.Append("SELECT NHC,IdCCProf,CONVERT(DATE,FechaEntrega) AS 'FechaEntrega',dbo.fn_ObtieneCodMed('P', Prof1_Codigo) AS 'P1C',Prof1_Cantidad AS 'P1N',dbo.fn_ObtieneEstatusMed(Prof1_MedEstatus) AS 'P1E', ")
        Q.Append("dbo.fn_ObtieneCodMed('P', Prof2_Codigo) AS 'P2C',Prof2_Cantidad AS 'P2N',dbo.fn_ObtieneEstatusMed(Prof2_MedEstatus) AS 'P2E', ")
        Q.Append("dbo.fn_ObtieneCodMed('P', Prof3_Codigo) AS 'P3C',Prof3_Cantidad AS 'P3N',dbo.fn_ObtieneEstatusMed(Prof3_MedEstatus) AS 'P3E', ")
        Q.Append("dbo.fn_ObtieneCodMed('P', Prof4_Codigo) AS 'P4C',Prof4_Cantidad AS 'P4N',dbo.fn_ObtieneEstatusMed(Prof4_MedEstatus) AS 'P4E',FechaRetorno,TiempoTMed,Embarazo,CD4,CV ")
        Q.Append("FROM ControlProf ")
        Q.Append("WHERE NHC = '" & nhc & "' ")
        Q.Append("ORDER BY CONVERT(DATE,FechaRetorno) DESC")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    Public Function ObtieneRegProf(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ObtieneRegProf"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT IdCCProf, FechaEntrega, Prof1_Codigo, Prof1_Cantidad, Prof1_Dosis, Prof1_Frecuencia, Prof1_MedEstatus, Prof1_DevCantidad, ")
        Q.Append("Prof2_Codigo, Prof2_Cantidad, Prof2_Dosis, Prof2_Frecuencia, Prof2_MedEstatus, Prof2_DevCantidad, ")
        Q.Append("Prof3_Codigo, Prof3_Cantidad, Prof3_Dosis, Prof3_Frecuencia, Prof3_MedEstatus, Prof3_DevCantidad, ")
        Q.Append("Prof4_Codigo, Prof4_Cantidad, Prof4_Dosis, Prof4_Frecuencia, Prof4_MedEstatus, Prof4_DevCantidad, ")
        Q.Append("FechaRetorno, TiempoTMed, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, CD4, CV, Observaciones ")
        Q.Append("FROM ControlProf ")
        Q.Append("WHERE IdCCProf = " & id)
        Query = Q.ToString()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdCCProf").ToString() + "|" + reader("FechaEntrega").ToString() + "|" + reader("Prof1_Codigo").ToString() + "|" + reader("Prof1_Cantidad").ToString() + "|" + reader("Prof1_Dosis").ToString() + "|" + reader("Prof1_Frecuencia").ToString() + "|" + reader("Prof1_MedEstatus").ToString() + "|" + reader("Prof1_DevCantidad").ToString() + "|" + reader("Prof2_Codigo").ToString() + "|" + reader("Prof2_Cantidad").ToString() + "|" + reader("Prof2_Dosis").ToString() + "|" + reader("Prof2_Frecuencia").ToString() + "|" + reader("Prof2_MedEstatus").ToString() + "|" + reader("Prof2_DevCantidad").ToString() + "|" + reader("Prof3_Codigo").ToString() + "|" + reader("Prof3_Cantidad").ToString() + "|" + reader("Prof3_Dosis").ToString() + "|" + reader("Prof3_Frecuencia").ToString() + "|" + reader("Prof3_MedEstatus").ToString() + "|" + reader("Prof3_DevCantidad").ToString() + "|" + reader("Prof4_Codigo").ToString() + "|" + reader("Prof4_Cantidad").ToString() + "|" + reader("Prof4_Dosis").ToString() + "|" + reader("Prof4_Frecuencia").ToString() + "|" + reader("Prof4_MedEstatus").ToString() + "|" + reader("Prof4_DevCantidad").ToString() + "|" + reader("FechaRetorno").ToString() + "|" + reader("TiempoTMed").ToString() + "|" + reader("CitaMedica").ToString() + "|" + reader("CitaFarmacia").ToString() + "|" + reader("Embarazo").ToString() + "|" + reader("TiempoRetorno").ToString() + "|" + reader("CD4").ToString() + "|" + reader("CV").ToString() + "|" + reader("Observaciones")
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No se Encontró Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function ConsultaRegistroARV(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ConsultaRegistroARV"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT A.IdCCARV, CONVERT(VARCHAR,A.FechaEntrega, 103) AS 'FechaEntrega', ")
        Q.Append("(CASE WHEN A.Med1_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med1_Codigo) ELSE '' END) AS 'Med1_Codigo', ")
        Q.Append("(CASE WHEN A.Med2_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med2_Codigo) ELSE '' END) AS 'Med2_Codigo', ")
        Q.Append("(CASE WHEN A.Med3_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med3_Codigo) ELSE '' END) AS 'Med3_Codigo', ")
        Q.Append("(CASE WHEN A.Med4_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med4_Codigo) ELSE '' END) AS 'Med4_Codigo', ")
        Q.Append("(CASE WHEN A.Med5_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med5_Codigo) ELSE '' END) AS 'Med5_Codigo', ")
        Q.Append("(CASE WHEN A.Med6_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med6_Codigo) ELSE '' END) AS 'Med6_Codigo', ")
        Q.Append("(CASE WHEN A.Med7_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med7_Codigo) ELSE '' END) AS 'Med7_Codigo', ")
        Q.Append("(CASE WHEN A.Med8_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med8_Codigo) ELSE '' END) AS 'Med8_Codigo' ")
        Q.Append("FROM ControlARV AS A ")
        Q.Append("WHERE A.IdCCARV = " & id)
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdCCARV").ToString() + "|" + reader("FechaEntrega").ToString() + "|" + reader("Med1_Codigo").ToString() + "|" + reader("Med2_Codigo").ToString() + "|" + reader("Med3_Codigo").ToString() + "|" + reader("Med4_Codigo").ToString() + "|" + reader("Med5_Codigo").ToString() + "|" + reader("Med6_Codigo").ToString() + "|" + reader("Med7_Codigo").ToString() + "|" + reader("Med8_Codigo").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe última fecha."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    '*Basales Paciente*//
    Public Function ObtieneBasales(ByVal nhc As String, ByVal usuario As String) As String
        _page = "db.ObtieneBasales"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT C.NomGenero, LTRIM(RTRIM(B.PrimerNombre)) + (CASE WHEN B.SegundoNombre IS NULL ")
        Q.Append("THEN '' WHEN B.SegundoNombre = 'SSN' THEN '' ELSE ' ' + LTRIM(RTRIM(B.SegundoNombre)) END) + ' ' + LTRIM(RTRIM(B.PrimerApellido)) ")
        Q.Append("+ (CASE WHEN B.SegundoApellido IS NULL THEN '' WHEN B.SegundoApellido = 'SSA' THEN '' ELSE ' ' + LTRIM(RTRIM(B.SegundoApellido)) END) AS 'Paciente', ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(B.TelefonoFijo)) IS NOT NULL THEN LTRIM(RTRIM(B.TelefonoFijo)) ELSE '' END) + ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(B.TelefonoMovil)) IS NOT NULL THEN ', ' + LTRIM(RTRIM(B.TelefonoMovil)) ELSE '' END) AS 'Telefono', ")
        Q.Append("CONVERT(VARCHAR,B.FechaNacimiento,103) AS 'FechaNacimiento', ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(B.Direccion)) IS NOT NULL THEN LTRIM(RTRIM(B.Direccion)) ELSE '' END) + ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(E.NomMunicipio)) IS NOT NULL THEN ', ' + LTRIM(RTRIM(E.NomMunicipio)) ELSE '' END) + ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(F.NomDepartamento)) IS NOT NULL THEN ', ' + LTRIM(RTRIM(F.NomDepartamento)) ELSE '' END) + ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(D.NomPais)) IS NOT NULL THEN ', ' + LTRIM(RTRIM(D.NomPais)) ELSE '' END) AS 'Direccion', ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(H.NomMotivoBaja)) IS NULL THEN 'Activo' ELSE LTRIM(RTRIM(H.NomMotivoBaja)) END) AS 'MotivoBaja' ")
        Q.Append("FROM PAC_ID AS A LEFT OUTER JOIN ")
        Q.Append("PAC_BAJA AS G ON A.IdPaciente = G.IdPaciente LEFT OUTER JOIN ")
        Q.Append("PAC_M_MOTIVOBAJA AS H ON G.MotivoBaja = H.IdMotivoBaja LEFT OUTER JOIN ")
        Q.Append("PAC_BASALES AS B ON A.IdPaciente = B.IdPaciente LEFT OUTER JOIN ")
        Q.Append("PAC_M_GENERO AS C ON B.IdGenero = C.IdGenero LEFT OUTER JOIN ")
        Q.Append("PAC_M_PAIS AS D ON B.PaisNacimiento = D.IdPais AND B.PaisResidencia = D.IdPais LEFT OUTER JOIN ")
        Q.Append("M_MUNICIPIO AS E ON B.MunicipioNacimiento = E.IdMunicipio AND B.MunicipioResidencia = E.IdMunicipio LEFT OUTER JOIN ")
        Q.Append("M_DEPARTAMENTO AS F ON B.DepartamentoNacimiento = F.IdDepartamento AND ")
        Q.Append("B.DepartamentoResidencia = F.IdDepartamento AND E.Departamento = F.IdDepartamento AND ")
        Q.Append("E.Departamento = F.IdDepartamento ")
        Q.Append("WHERE (A.NHC = '" & nhc & "')")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn2)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("NomGenero") + "|" + reader("Paciente") + "|" + reader("Telefono") + "|" + reader("FechaNacimiento") + "|" + reader("Direccion") + "|" + reader("MotivoBaja")
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No se Encontró Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function ObtieneBasalesP(ByVal nhc As String, ByVal usuario As String) As String
        _page = "db.ObtieneBasalesP"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT B.NomGenero, LTRIM(RTRIM(A.PrimerNombre)) + (CASE WHEN A.SegundoNombre IS NULL ")
        Q.Append("THEN '' WHEN A.SegundoNombre = 'SSN' THEN '' ELSE ' ' + LTRIM(RTRIM(A.SegundoNombre)) END) + ' ' + LTRIM(RTRIM(A.PrimerApellido)) ")
        Q.Append("+ (CASE WHEN A.SegundoApellido IS NULL THEN '' WHEN A.SegundoApellido = 'SSA' THEN '' ELSE ' ' + LTRIM(RTRIM(A.SegundoApellido)) END) AS 'Paciente', ")
        'Q.Append("(CASE WHEN A.FechaNacimiento = '' THEN '' ELSE CONVERT(VARCHAR, CONVERT(DATE, (SUBSTRING(A.FechaNacimiento,4,2)+'/'+SUBSTRING(A.FechaNacimiento,1,2)+'/'+SUBSTRING(A.FechaNacimiento,7,4))),103) END) AS 'FechaNacimiento', A.Telefono, A.Direccion, ")
        'Q.Append("(CASE WHEN A.FechaNacimiento = '' THEN '' ELSE CONVERT(VARCHAR, CONVERT(DATE, (SUBSTRING(A.FechaNacimiento,1,2)+'/'+SUBSTRING(A.FechaNacimiento,4,2)+'/'+SUBSTRING(A.FechaNacimiento,7,4))),103) END) AS 'FechaNacimiento', A.Telefono, A.Direccion, ")
        Q.Append("(CASE WHEN A.FechaNacimiento = '' THEN '' ELSE A.FechaNacimiento END) AS 'FechaNacimiento', A.Telefono, A.Direccion, ")
        Q.Append("(CASE WHEN LTRIM(RTRIM(C.NomMotivoBaja)) IS NULL THEN '' ELSE LTRIM(RTRIM(C.NomMotivoBaja)) END) AS 'MotivoBaja' ")
        Q.Append("FROM BasalesPediatria AS A LEFT OUTER JOIN ")
        Q.Append("PAC_M_GENERO AS B ON A.Genero = B.IdGenero LEFT OUTER JOIN ")
        Q.Append("PAC_M_MOTIVOBAJA AS C ON A.IdBaja = C.IdMotivoBaja ")
        Q.Append("WHERE (A.NHC = '" & nhc & "')")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("NomGenero") + "|" + reader("Paciente") + "|" + reader("Telefono") + "|" + reader("FechaNacimiento") + "|" + reader("Direccion") + "|" + reader("MotivoBaja")
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No se Encontró Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function ObtieneBasalesP2(ByVal nhc As String, ByVal usuario As String) As String
        _page = "db.ObtieneBasalesP2"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT A.Genero, A.PrimerNombre, A.SegundoNombre, A.PrimerApellido, A.SegundoApellido, ")
        'Q.Append("(CASE WHEN A.FechaNacimiento = '' THEN '' ELSE CONVERT(VARCHAR, CONVERT(DATE, (SUBSTRING(A.FechaNacimiento,4,2)+'/'+SUBSTRING(A.FechaNacimiento,1,2)+'/'+SUBSTRING(A.FechaNacimiento,7,4))),103) END) AS 'FechaNacimiento', A.Telefono, A.Direccion, IdBaja ")
        Q.Append("(CASE WHEN A.FechaNacimiento = '' THEN '' ELSE A.FechaNacimiento END) AS 'FechaNacimiento', A.Telefono, A.Direccion, IdBaja ")
        Q.Append("FROM BasalesPediatria AS A ")
        Q.Append("WHERE (A.NHC = '" & nhc & "')")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("Genero").ToString() + "|" + reader("PrimerNombre").ToString() + "|" + reader("SegundoNombre").ToString() + "|" + reader("PrimerApellido").ToString() + "|" + reader("SegundoApellido").ToString() + "|" + reader("FechaNacimiento").ToString() + "|" + reader("Telefono").ToString() + "|" + reader("Direccion").ToString() + "|" + reader("IdBaja").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No se Encontró Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    '*Lista FFProf-FFARV*//
    Public Function busquedaMedProf(ByVal tipo As Integer, ByVal usuario As String) As DataTable
        _page = "db.busquedaMedProf"
        Dim Query As String = ""
        If tipo = "1" Then
            Query = "SELECT A.IdFFARV, A.Codigo, B.NomARV, C.NomFF, A.Concentracion "
            Query += "FROM FFARV AS A LEFT OUTER JOIN "
            Query += "MedARV AS B ON A.IdARV = B.IdARV LEFT OUTER JOIN "
            Query += "FormaFarmaceutica AS C ON A.IdFF = C.IdFF "
            Query += "ORDER BY A.Codigo ASC"
        ElseIf tipo = "2" Then
            Query = "SELECT A.IdFFProf, A.Codigo, B.NomProfilaxis, C.NomFF, A.Concentracion "
            Query += "FROM FFProf AS A LEFT OUTER JOIN "
            Query += "MedProf AS B ON A.IdProf = B.IdProf LEFT OUTER JOIN "
            Query += "FormaFarmaceutica AS C ON A.IdFF = C.IdFF "
            Query += "ORDER BY A.Codigo ASC"
        End If
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    Public Function ContenidoFFARV(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoFFARV"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdARV, IdFF, Concentracion FROM FFARV WHERE IdFFARV = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdARV").ToString() + "|" + reader("IdFF").ToString() + "|" + reader("Concentracion").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function ContenidoFFProf(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoFFProf"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdProf, IdFF, Concentracion FROM FFProf WHERE IdFFProf = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdProf").ToString() + "|" + reader("IdFF").ToString() + "|" + reader("Concentracion").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function busquedaCod(ByVal tipo As Integer, ByVal usuario As String) As DataTable
        _page = "db.busquedaCod"
        Dim Query As String = ""
        If tipo = "1" Then
            Query = "SELECT IdARV, NomARV FROM MedARV ORDER BY IdARV"
        ElseIf tipo = "2" Then
            Query = "SELECT IdProf, NomProfilaxis FROM MedProf ORDER BY IdProf"
        End If
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    Public Function ContenidoCodARV(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoCodARV"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdARV, NomARV FROM MedARV WHERE IdARV = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdARV").ToString() + "|" + reader("NomARV").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function ContenidoCodProf(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoCodProf"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdProf, NomProfilaxis FROM MedProf WHERE IdProf = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdProf").ToString() + "|" + reader("NomProfilaxis").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    '*Lista FF*//
    Public Function busquedaff(ByVal usuario As String) As DataTable
        _page = "db.busquedaff"
        Dim Query As String = ""
        Query = "SELECT IdFF, NomFF FROM FormaFarmaceutica ORDER BY IdFF"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Graba FF*//
    Public Sub GrabaFF(ByVal ff As String, ByVal usuario As String)
        _page = "db.GrabaFF"
        Dim sql As String = String.Format("INSERT INTO FormaFarmaceutica (NomFF) VALUES ('{0}')", ff)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Function ContenidoFF(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoFF"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdFF, NomFF FROM FormaFarmaceutica WHERE IdFF = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdFF").ToString() + "|" + reader("NomFF").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Sub ActualizaFF(ByVal id As String, ByVal datos As String, ByVal usuario As String)
        _page = "db.ActualizaFF"
        'Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE FormaFarmaceutica SET NomFF = '{1}', FechaModificacion = GETDATE() WHERE IdFF = '{0}'", id, datos.ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Lista Estatus*//
    Public Function busquedaEstatus(ByVal usuario As String) As DataTable
        _page = "db.busquedaEstatus"
        Dim Query As String = ""
        Query = "SELECT IdEstatus, Codigo, Descripcion FROM Estatus ORDER BY IdEstatus"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Graba Estatus*//
    Public Sub GrabaEstatus(ByVal codigo As String, ByVal descripcion As String, ByVal usuario As String)
        _page = "db.GrabaEstatus"
        Dim sql As String = String.Format("INSERT INTO Estatus (Codigo, Descripcion) VALUES ('{0}', '{1}')", codigo, descripcion)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Function ContenidoEstatus(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoEstatus"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdEstatus, Codigo, Descripcion FROM Estatus WHERE IdEstatus = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdEstatus").ToString() + "|" + reader("Codigo").ToString() + "|" + reader("Descripcion").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Sub ActualizaEstatus(ByVal id As String, ByVal codigo As String, ByVal descripcion As String, ByVal usuario As String)
        _page = "db.ActualizaEstatus"
        'Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE Estatus SET Codigo = '{1}', Descripcion = '{2}' WHERE IdEstatus = '{0}'", id, codigo, descripcion)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Lista Frecuencia*//
    Public Function busquedaFx(ByVal usuario As String) As DataTable
        _page = "db.busquedaFx"
        Dim Query As String = ""
        Query = "SELECT IdFrecuencia, Codigo, Descripcion FROM Frecuencia ORDER BY IdFrecuencia"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Graba Frecuencia*//
    Public Sub GrabaFx(ByVal codigo As String, ByVal descripcion As String, ByVal usuario As String)
        _page = "db.GrabaFx"
        Dim sql As String = String.Format("INSERT INTO Frecuencia (Codigo, Descripcion) VALUES ('{0}', '{1}')", codigo, descripcion)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Function ContenidoFx(ByVal id As String, ByVal usuario As String) As String
        _page = "db.ContenidoFx"
        Dim Q As New StringBuilder()
        Dim Query As String = "SELECT IdFrecuencia, Codigo, Descripcion FROM Frecuencia WHERE IdFrecuencia = " & id
        Dim Str As String = ""
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdFrecuencia").ToString() + "|" + reader("Codigo").ToString() + "|" + reader("Descripcion").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe Información."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Sub ActualizaFx(ByVal id As String, ByVal codigo As String, ByVal descripcion As String, ByVal usuario As String)
        _page = "db.ActualizaFx"
        'Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE Frecuencia SET Codigo = '{1}', Descripcion = '{2}' WHERE IdFrecuencia = '{0}'", id, codigo.ToString(), descripcion.ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Codigo MedARV*//
    Public Function ObtieneMedARVProf(ByVal tipo As String, ByVal usuario As String) As DataTable
        _page = "db.ObtieneMedARVProf"
        Dim Query As String = ""
        If tipo = "1" Then
            Query = "SELECT IdARV, NomARV FROM MedARV ORDER BY NomARV ASC"
        ElseIf tipo = "2" Then
            Query = "SELECT IdProf, NomProfilaxis FROM MedProf ORDER BY NomProfilaxis ASC"
        End If

        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Codigo FF*//
    Public Function ObtieneFF(ByVal usuario As String) As DataTable
        _page = "db.ObtieneFF"
        Dim Query As String = "SELECT IdFF, NomFF FROM FormaFarmaceutica ORDER BY NomFF ASC"

        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Codigo ARV/Medicamentos*//
    Public Function ObtieneARVMedicamento(ByVal tipo As String, ByVal usuario As String) As DataTable
        _page = "db.ObtieneARVMedicamento"
        Dim Query As String = ""
        If tipo = "1" Then
            Query = "SELECT IdFFARV, Codigo FROM FFARV ORDER BY Codigo ASC"
        ElseIf tipo = "2" Then
            Query = "SELECT IdFFProf, Codigo FROM FFProf ORDER BY Codigo ASC"
        End If

        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Codigo Estatus*//
    Public Function ObtieneEstatus(ByVal usuario As String) As DataTable
        _page = "db.ObtieneEstatus"
        Dim Query As String = "SELECT IdEstatus, Codigo FROM Estatus ORDER BY Codigo ASC"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Codigo Frecuencia*//
    Public Function ObtieneFrecuenia(ByVal usuario As String) As DataTable
        _page = "db.ObtieneFrecuenia"
        Dim Query As String = "SELECT IdFrecuencia FROM Frecuencia ORDER BY IdFrecuencia ASC"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Codigo Embarazo*//
    Public Function ObtieneEmbarazo(ByVal usuario As String) As DataTable
        _page = "db.ObtieneEmbarazo"
        Dim Query As String = "SELECT IdEmbarazo FROM Embarazo ORDER BY IdEmbarazo ASC"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Codigo Baja*//
    Public Function ObtieneBaja(ByVal usuario As String) As DataTable
        _page = "db.ObtieneBaja"
        Dim Query As String = "SELECT IdMotivoBaja, NomMotivoBaja FROM PAC_M_MOTIVOBAJA ORDER BY IdMotivoBaja ASC"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim adapter As New SqlDataAdapter()
                adapter.SelectCommand = New SqlCommand(Query, connection)
                adapter.SelectCommand.CommandTimeout = TimeoutDB
                adapter.Fill(Ds, _page)
                adapter.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
            Return Ds.Tables(0)
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Return Nothing
        End Try
    End Function

    '*Ultima Fecha Entrega*//
    Public Function ObtieneUltimoReg(ByVal nhc As String, ByVal usuario As String) As String
        _page = "db.ObtieneUltimoReg"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT A.IdCCARV, CONVERT(VARCHAR,A.FechaEntrega, 103) AS 'FechaEntrega', ")
        Q.Append("(CASE WHEN A.Med1_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med1_Codigo) ELSE '' END) AS 'Med1_Codigo', ")
        Q.Append("(CASE WHEN A.Med2_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med2_Codigo) ELSE '' END) AS 'Med2_Codigo', ")
        Q.Append("(CASE WHEN A.Med3_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med3_Codigo) ELSE '' END) AS 'Med3_Codigo', ")
        Q.Append("(CASE WHEN A.Med4_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med4_Codigo) ELSE '' END) AS 'Med4_Codigo', ")
        Q.Append("(CASE WHEN A.Med5_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med5_Codigo) ELSE '' END) AS 'Med5_Codigo', ")
        Q.Append("(CASE WHEN A.Med6_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med6_Codigo) ELSE '' END) AS 'Med6_Codigo', ")
        Q.Append("(CASE WHEN A.Med7_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med7_Codigo) ELSE '' END) AS 'Med7_Codigo', ")
        Q.Append("(CASE WHEN A.Med8_Codigo <> 0 THEN (SELECT Codigo FROM FFARV WHERE IdFFARV = A.Med8_Codigo) ELSE '' END) AS 'Med8_Codigo' ")
        Q.Append("FROM ControlARV AS A ")
        Q.Append("WHERE A.NHC = '" & nhc & "' ")
        Q.Append("AND A.IdCCARV = (SELECT TOP(1) B.IdCCARV FROM ControlARV AS B WHERE B.NHC = A.NHC AND B.FechaEntrega = (SELECT DISTINCT MAX(C.FechaEntrega) FROM ControlARV AS C WHERE C.NHC = B.NHC) ORDER BY B.IdCCARV DESC) ")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdCCARV").ToString() + "|" + reader("FechaEntrega").ToString() + "|" + reader("Med1_Codigo").ToString() + "|" + reader("Med2_Codigo").ToString() + "|" + reader("Med3_Codigo").ToString() + "|" + reader("Med4_Codigo").ToString() + "|" + reader("Med5_Codigo").ToString() + "|" + reader("Med6_Codigo").ToString() + "|" + reader("Med7_Codigo").ToString() + "|" + reader("Med8_Codigo").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe última fecha."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    Public Function ObtieneUltimoRegProf(ByVal nhc As String, ByVal usuario As String) As String
        _page = "db.ObtieneUltimoRegProf"
        Dim Q As New StringBuilder()
        Dim Query As String = ""
        Dim Str As String = ""
        Q.Append("SELECT A.IdCCPROF, CONVERT(VARCHAR,A.FechaEntrega, 103) AS 'FechaEntrega', ")
        Q.Append("(CASE WHEN A.Prof1_Codigo <> 0 THEN (SELECT Codigo FROM FFProf WHERE IdFFProf = A.Prof1_Codigo) ELSE '' END) AS 'Prof1_Codigo', ")
        Q.Append("(CASE WHEN A.Prof2_Codigo <> 0 THEN (SELECT Codigo FROM FFProf WHERE IdFFProf = A.Prof2_Codigo) ELSE '' END) AS 'Prof2_Codigo', ")
        Q.Append("(CASE WHEN A.Prof3_Codigo <> 0 THEN (SELECT Codigo FROM FFProf WHERE IdFFProf = A.Prof3_Codigo) ELSE '' END) AS 'Prof3_Codigo', ")
        Q.Append("(CASE WHEN A.Prof4_Codigo <> 0 THEN (SELECT Codigo FROM FFProf WHERE IdFFProf = A.Prof4_Codigo) ELSE '' END) AS 'Prof4_Codigo' ")
        Q.Append("FROM ControlProf AS A ")
        Q.Append("WHERE A.FechaEntrega = (SELECT DISTINCT MAX(B.FechaEntrega) FROM ControlProf AS B WHERE B.NHC = '" & nhc & "') ")
        Q.Append("AND A.NHC = '" & nhc & "'")
        Query = Q.ToString()
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(Query, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                If reader IsNot Nothing Then
                    While reader.Read()
                        Str = "True|" + reader("IdCCPROF").ToString() + "|" + reader("FechaEntrega").ToString() + "|" + reader("Prof1_Codigo").ToString() + "|" + reader("Prof2_Codigo").ToString() + "|" + reader("Prof3_Codigo").ToString() + "|" + reader("Prof4_Codigo").ToString()
                        Exit While
                    End While
                End If
                If Str = String.Empty Then
                    Str = "False|No existe última fecha."
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
            Str = "False|" + ex.Message
        End Try
        Return Str
    End Function

    '*Graba Controles*//
    Public Sub GrabaUFechaControlARV(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaUFechaControlARV"
        Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE ControlARV SET Med1_DevCantidad = {1}, Med2_DevCantidad = {2}, Med3_DevCantidad = {3}, Med4_DevCantidad = {4}, Med5_DevCantidad = {5}, Med6_DevCantidad = {6}, Med7_DevCantidad = {7}, Med8_DevCantidad = {8}, Adherencia = {9}, FechaModificacion = GETDATE() WHERE IdCCARV = {0}", d(0).ToString(), d(1).ToString(), d(2).ToString(), d(3).ToString(), d(4).ToString(), d(5).ToString(), d(6).ToString(), d(7).ToString(), d(8).ToString(), d(9).ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub GrabaControlARV(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaControlARV"
        Dim sql As String = ""
        Dim d As String() = datos.Split("|")
        'NHC, FechaEntrega, Med1_Codigo, Med1_Cantidad, Med1_Dosis, Med1_Frecuencia, Med1_UExCantidad, Med1_ARVEstatus, Med2_Codigo, Med2_Cantidad, Med2_Dosis, Med2_Frecuencia, Med2_UExCantidad, Med2_ARVEstatus, Med3_Codigo, Med3_Cantidad, Med3_Dosis, Med3_Frecuencia, Med3_UExCantidad, Med3_ARVEstatus, Med4_Codigo, Med4_Cantidad, Med4_Dosis, Med4_Frecuencia, Med4_UExCantidad, Med4_ARVEstatus, Med5_Codigo, Med5_Cantidad, Med5_Dosis, Med5_Frecuencia, Med5_UExCantidad, Med5_ARVEstatus, Med6_Codigo, Med6_Cantidad, Med6_Dosis, Med6_Frecuencia, Med6_UExCantidad, Med6_ARVEstatus, Med7_Codigo, Med7_Cantidad, Med7_Dosis, Med7_Frecuencia, Med7_UExCantidad, Med7_ARVEstatus, Med8_Codigo, Med8_Cantidad, Med8_Dosis, Med8_Frecuencia, Med8_UExCantidad, Med8_ARVEstatus, FechaRetorno, TiempoTARV, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, CD4, CV, Observaciones, NomUsuario
        sql = "INSERT INTO ControlARV (NHC, FechaEntrega, Med1_Codigo, Med1_Cantidad, Med1_Dosis, Med1_Frecuencia, Med1_UExCantidad, Med1_ARVEstatus, Med2_Codigo, Med2_Cantidad, Med2_Dosis, Med2_Frecuencia, Med2_UExCantidad, Med2_ARVEstatus, Med3_Codigo, Med3_Cantidad, Med3_Dosis, Med3_Frecuencia, Med3_UExCantidad, Med3_ARVEstatus, Med4_Codigo, Med4_Cantidad, Med4_Dosis, Med4_Frecuencia, Med4_UExCantidad, Med4_ARVEstatus, Med5_Codigo, Med5_Cantidad, Med5_Dosis, Med5_Frecuencia, Med5_UExCantidad, Med5_ARVEstatus, Med6_Codigo, Med6_Cantidad, Med6_Dosis, Med6_Frecuencia, Med6_UExCantidad, Med6_ARVEstatus, Med7_Codigo, Med7_Cantidad, Med7_Dosis, Med7_Frecuencia, Med7_UExCantidad, Med7_ARVEstatus, Med8_Codigo, Med8_Cantidad, Med8_Dosis, Med8_Frecuencia, Med8_UExCantidad, Med8_ARVEstatus, FechaRetorno, TiempoTARV, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, CD4, CV, Observaciones, NomUsuario) "
        sql += String.Format("VALUES('{0}', CONVERT(date,'{1}'), {2}, {3}, '{4}', {5}, {6}, {7}, {8}, {9}, '{10}', {11}, {12}, {13}, {14}, {15}, '{16}', {17}, {18}, {19}, {20}, {21}, '{22}', {23}, {24}, {25}, {26}, {27}, '{28}', {29}, {30}, {31}, {32}, {33}, '{34}', {35}, {36}, {37}, {38}, {39}, '{40}', {41}, {42}, {43}, {44}, {45}, '{46}', {47}, {48}, {49}, CONVERT(date,'{50}'), {51}, '{52}', '{53}', '{54}', {55}, '{56}', '{57}', '{58}', '{59}')", d(0).ToString(), d(1).ToString(), d(2).ToString(), d(3).ToString(), d(4).ToString(), d(5).ToString(), d(6).ToString(), d(7).ToString(), d(8).ToString(), d(9).ToString(), d(10).ToString(), d(11).ToString(), d(12).ToString(), d(13).ToString(), d(14).ToString(), d(15).ToString(), d(16).ToString(), d(17).ToString(), d(18).ToString(), d(19).ToString(), d(20).ToString(), d(21).ToString(), d(22).ToString(), d(23).ToString(), d(24).ToString(), d(25).ToString(), d(26).ToString(), d(27).ToString(), d(28).ToString(), d(29).ToString(), d(30).ToString(), d(31).ToString(), d(32).ToString(), d(33).ToString(), d(34).ToString(), d(35).ToString(), d(36).ToString(), d(37).ToString(), d(38).ToString(), d(39).ToString(), d(40).ToString(), d(41).ToString(), d(42).ToString(), d(43).ToString(), d(44).ToString(), d(45).ToString(), d(46).ToString(), d(47).ToString(), d(48).ToString(), d(49).ToString(), d(50).ToString(), d(51).ToString(), d(52).ToString(), d(53).ToString(), d(54).ToString(), d(55).ToString(), d(56).ToString(), d(57).ToString(), d(58).ToString(), usuario)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub GrabaUFechaControlPROF(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaUFechaControlPROF"
        Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE ControlPROF SET Prof1_DevCantidad = {1}, Prof2_DevCantidad = {2}, Prof3_DevCantidad = {3}, Prof4_DevCantidad = {4}, FechaModificacion = GETDATE() WHERE IdCCProf = {0}", d(0).ToString(), d(1).ToString(), d(2).ToString(), d(3).ToString(), d(4).ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub GrabaControlPROF(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaControlPROF"
        Dim sql As String = ""
        Dim d As String() = datos.Split("|")
        'NHC, FechaEntrega, Prof1_Codigo, Prof1_Cantidad, Prof1_Dosis, Prof1_Frecuencia, Prof1_MedEstatus, Prof2_Codigo, Prof2_Cantidad, Prof2_Dosis, Prof2_Frecuencia, Prof2_MedEstatus, Prof3_Codigo, Prof3_Cantidad, Prof3_Dosis, Prof3_Frecuencia, Prof3_MedEstatus, Prof4_Codigo, Prof4_Cantidad, Prof4_Dosis, Prof4_Frecuencia, Prof4_MedEstatus, FechaRetorno, TiempoTMed, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, CD4, CV, Observaciones
        sql = "INSERT INTO ControlPROF (NHC, FechaEntrega, Prof1_Codigo, Prof1_Cantidad, Prof1_Dosis, Prof1_Frecuencia, Prof1_MedEstatus, Prof2_Codigo, Prof2_Cantidad, Prof2_Dosis, Prof2_Frecuencia, Prof2_MedEstatus, Prof3_Codigo, Prof3_Cantidad, Prof3_Dosis, Prof3_Frecuencia, Prof3_MedEstatus, Prof4_Codigo, Prof4_Cantidad, Prof4_Dosis, Prof4_Frecuencia, Prof4_MedEstatus, FechaRetorno, TiempoTMed, CitaMedica, CitaFarmacia, Embarazo, TiempoRetorno, CD4, CV, Observaciones, NomUsuario) "
        sql += String.Format("VALUES('{0}', CONVERT(date,'{1}'), {2}, {3}, '{4}', {5}, {6}, {7}, {8}, '{9}', {10}, {11}, {12}, {13}, '{14}', {15}, {16}, {17}, {18}, '{19}', {20}, {21}, CONVERT(date,'{22}'), {23}, '{24}', '{25}', '{26}', {27}, '{28}', '{29}', '{30}', '{31}')", d(0).ToString(), d(1).ToString(), d(2).ToString(), d(3).ToString(), d(4).ToString(), d(5).ToString(), d(6).ToString(), d(7).ToString(), d(8).ToString(), d(9).ToString(), d(10).ToString(), d(11).ToString(), d(12).ToString(), d(13).ToString(), d(14).ToString(), d(15).ToString(), d(16).ToString(), d(17).ToString(), d(18).ToString(), d(19).ToString(), d(20).ToString(), d(21).ToString(), d(22).ToString(), d(23).ToString(), d(24).ToString(), d(25).ToString(), d(26).ToString(), d(27).ToString(), d(28).ToString(), d(29).ToString(), d(30).ToString(), usuario)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Graba FFProf-FFARV*//
    Public Sub GrabaFFARV(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaFFARV"
        Dim sql As String = ""
        Dim d As String() = datos.Split("|")
        sql = "INSERT INTO FFARV (IdARV, IdFF, Concentracion, Codigo) "
        'sql += String.Format("VALUES({0}, {1}, '{2}', (SELECT (CASE WHEN LEN({0}) = 1 THEN ('0' + CONVERT(VARCHAR, {0})) ELSE CONVERT(VARCHAR, {0}) END) +'-'+ (CASE WHEN LEN(COUNT(Codigo)+1) = 1 THEN ('0' + CONVERT(VARCHAR, COUNT(Codigo)+1)) ELSE CONVERT(VARCHAR, COUNT(Codigo)+1) END) FROM FFARV WHERE IdARV = {0}))", d(0).ToString(), d(1).ToString(), d(2).ToString())
        sql += String.Format("VALUES({0}, {1}, '{2}', (SELECT RIGHT('00' + CAST({0} AS VARCHAR(2)),2) + '-' + RIGHT('00' + CAST(COUNT(Codigo) + 1 AS VARCHAR(2)),2) FROM FFARV WHERE IdARV = {0}))", d(0).ToString(), d(1).ToString(), d(2).ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub ActualizaFFARV(ByVal id As String, ByVal datos As String, ByVal usuario As String)
        _page = "db.ActualizaFFARV"
        'Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE FFARV SET Concentracion = '{1}', FechaModificacion = GETDATE() WHERE IdFFARV = '{0}'", id, datos.ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub GrabaFFProf(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaFFProf"
        Dim sql As String = ""
        Dim d As String() = datos.Split("|")
        sql = "INSERT INTO FFProf (IdProf, IdFF, Concentracion, Codigo) "
        'sql += String.Format("VALUES({0}, {1}, '{2}', (SELECT (CASE WHEN LEN({0}) = 1 THEN ('0' + CONVERT(VARCHAR, {0})) ELSE CONVERT(VARCHAR, {0}) END) +'-'+ (CASE WHEN LEN(COUNT(Codigo)+1) = 1 THEN ('0' + CONVERT(VARCHAR, COUNT(Codigo)+1)) ELSE CONVERT(VARCHAR, COUNT(Codigo)+1) END) FROM FFProf WHERE IdProf = {0}))", d(0).ToString(), d(1).ToString(), d(2).ToString())
        sql += String.Format("VALUES({0}, {1}, '{2}', (SELECT RIGHT('000' + CAST({0} AS VARCHAR(3)),3) + '-' + RIGHT('00' + CAST(COUNT(Codigo) + 1 AS VARCHAR(2)),2) FROM FFProf WHERE IdProf = {0}))", d(0).ToString(), d(1).ToString(), d(2).ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub ActualizaFFProf(ByVal id As String, ByVal datos As String, ByVal usuario As String)
        _page = "db.ActualizaFFProf"
        'Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE FFProf SET Concentracion = '{1}', FechaModificacion = GETDATE() WHERE IdFFProf = '{0}'", id, datos.ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Graba LProf-LARV*//
    Public Sub GrabaLARV(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaLARV"
        Dim sql As String = String.Format("INSERT INTO MedARV (NomARV) VALUES('{0}')", datos)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub ActualizaLARV(ByVal id As String, ByVal datos As String, ByVal usuario As String)
        _page = "db.ActualizaLARV"
        Dim sql As String = String.Format("UPDATE MedARV SET NomARV = '{1}', FechaModificacion = GETDATE() WHERE IdARV = '{0}'", id, datos.ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub GrabaLProf(ByVal datos As String, ByVal usuario As String)
        _page = "db.GrabaLProf"
        Dim sql As String = String.Format("INSERT INTO MedProf (NomProfilaxis) VALUES('{0}')", datos)
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page
            GrabarErrores(usuario & "|" & _page & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    Public Sub ActualizaLProf(ByVal id As String, ByVal datos As String, ByVal usuario As String)
        _page = "db.ActualizaLProf"
        Dim sql As String = String.Format("UPDATE MedProf SET NomProfilaxis = '{1}', FechaModificacion = GETDATE() WHERE IdProf = '{0}'", id, datos.ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + id
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Actualiza Basal Pediatrico*//
    Public Sub ActualizaBPediatrico(ByVal nhc As String, ByVal datos As String, ByVal usuario As String)
        _page = "db.ActualizaBPediatrico"
        Dim d As String() = datos.Split("|")
        Dim sql As String = String.Format("UPDATE BasalesPediatria SET PrimerNombre = '{1}', SegundoNombre = '{2}', PrimerApellido = '{3}', SegundoApellido = '{4}', Genero = {5}, FechaNacimiento = '{6}', Telefono = '{7}', Direccion = '{8}', IdBaja = {9} WHERE NHC = '{0}'", d(0).ToString(), d(1).ToString(), d(2).ToString(), d(3).ToString(), d(4).ToString(), d(5).ToString(), d(6).ToString(), d(7).ToString(), d(8).ToString(), d(9).ToString())
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page + "_" + nhc
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
        End Try
    End Sub

    '*Agrega Basal Pediatrico*//
    Public Function AgregaBPediatrico(ByVal nhc As String, ByVal datos As String, ByVal usuario As String) As String
        _page = "db.AgregaBPediatrico"
        Dim sql As String
        Dim str As String
        Dim x As Boolean = False
        sql = "SELECT NHC FROM BasalesPediatria WHERE NHC = '" & nhc & "'"
        Dim Ds As New DataSet()
        Try
            Using connection As New SqlConnection(_cn1)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.CommandTimeout = TimeoutDB
                Dim reader As SqlDataReader = command.ExecuteReader()
                'If reader IsNot Nothing Then
                If reader.HasRows Then
                    x = True
                Else
                    x = False
                End If
                reader.Dispose()
                reader.Close()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            _error = ex.Message
            _pageO = _page & "_" & nhc
            GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
            str = "False|" + ex.Message
        End Try
        If x Then
            str = "False|El NHC pediatrico ya existe, revise porfavor."
        Else
            Dim d As String() = datos.Split("|")
            sql = String.Format("INSERT INTO BasalesPediatria (NHC, PrimerNombre, SegundoNombre, PrimerApellido, SegundoApellido, Genero, FechaNacimiento, Telefono, Direccion, IdBaja) VALUES('{0}', '{1}', '{2}', '{3}', '{4}', {5}, '{6}', '{7}', '{8}', {9})", d(0).ToString(), d(1).ToString(), d(2).ToString(), d(3).ToString(), d(4).ToString(), d(5).ToString(), d(6).ToString(), d(7).ToString(), d(8).ToString(), d(9).ToString())
            Try
                Using connection As New SqlConnection(_cn1)
                    connection.Open()
                    Dim command As New SqlCommand(sql, connection)
                    command.ExecuteNonQuery()
                    command.Dispose()
                    connection.Dispose()
                    connection.Close()
                End Using
                str = "True|Ok"
            Catch ex As SqlException
                _error = ex.Message
                _pageO = _page + "_" + nhc
                GrabarErrores(usuario & "|" & _pageO & "|" & ex.Number & "|" & ex.Message)
                str = "False|" + ex.Message
            End Try
        End If
        Return str
    End Function

    '*Graba Errores*//
    Public Sub GrabarErrores(ByVal Errores As String)
        Try
            Dim r As String() = Errores.Split("|")
            Dim r3 As String = r(3).Replace("'", "").ToString()
            Using connection As New SqlConnection(_cn1)
                Dim sql As String = ""
                sql = String.Format("insert into logEBD(IdUsuario,Pagina,Error,ErrorMsg) values('{0}', '{1}', '{2}', '{3}')", r(0), r(1), r(2), r3)
                connection.Open()
                Dim command As New SqlCommand(sql, connection)
                command.ExecuteNonQuery()
                command.Dispose()
                connection.Dispose()
                connection.Close()
            End Using
        Catch ex As SqlException
            Dim r As String() = Errores.Split("|")
            Dim narchivo As String = "FARMACIA_EBD"
            Dim path As String = ConfigurationManager.AppSettings("LogEBD")
            Dim archivo As String = (path & narchivo) & System.DateTime.Now.Year.ToString() & System.DateTime.Now.Month.ToString("00") & System.DateTime.Now.Day.ToString("00") & ".txt"
            Dim sw As New StreamWriter(archivo, True)
            sw.WriteLine(System.DateTime.Now.ToLongTimeString() & " - " & r(0) & " - Página: " & r(1))
            sw.WriteLine("Error No.: " & r(2))
            sw.WriteLine("Error Mensaje: " & r(3))
            sw.WriteLine("---------------------------------------------------")
            sw.WriteLine("Error Base de Datos al Grabar")
            sw.WriteLine("Error: " & ex.Number)
            sw.WriteLine("Error Mensaje: " & ex.Message)
            sw.WriteLine("---------------------------------------------------")
            sw.Close()
        End Try
    End Sub

End Class
